// =========== FACE RECOGNITION SIMPLE HELPER ===========
// Beginner-friendly face recognition using CDN

class FaceRecognition {
    static modelsLoaded = false;
    static videoElement = null;

    // =========== LOAD MODELS FROM CDN ===========
    static async loadModels() {
        console.log('🤖 Loading face recognition models...');
        
        try {
            // Load models from CDN (no need to download files!)
            await Promise.all([
                faceapi.nets.tinyFaceDetector.loadFromUri('https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights'),
                faceapi.nets.faceLandmark68Net.loadFromUri('https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights'),
                faceapi.nets.faceRecognitionNet.loadFromUri('https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights')
            ]);
            
            this.modelsLoaded = true;
            console.log('✅ Face recognition models loaded!');
            return true;
            
        } catch (error) {
            console.error('❌ Failed to load models:', error);
            throw new Error('Face models failed to load');
        }

    }

    // =========== START CAMERA ===========
    static async startCamera(videoElementId = 'video') {
        console.log('📸 Starting camera...');
        
        try {
            this.videoElement = document.getElementById(videoElementId);
            if (!this.videoElement) {
                throw new Error('Video element not found');
            }

            // Get camera access
            const stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'user' // Front camera
                },
                audio: false
            });

            this.videoElement.srcObject = stream;
            
            // Wait for video to be ready
            await new Promise((resolve) => {
                this.videoElement.onloadedmetadata = () => {
                    resolve();
                };
            });

            console.log('✅ Camera started successfully');
            return true;
            
        } catch (error) {
            console.error('❌ Camera error:', error);
            
            let errorMessage = 'Camera error';
            if (error.name === 'NotAllowedError') {
                errorMessage = 'Please allow camera access';
            } else if (error.name === 'NotFoundError') {
                errorMessage = 'No camera found';
            }
            
            throw new Error(errorMessage);
        }
    }

    // =========== CAPTURE FACE (SIMPLE VERSION) ===========
    static async captureFace() {
        console.log('📷 Capturing face...');
        
        if (!this.modelsLoaded) {
            throw new Error('Face recognition models not loaded');
        }


        try {
            // Wait for face to be visible
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Detect faces
            const detections = await faceapi.detectAllFaces(
                this.videoElement,
                new faceapi.TinyFaceDetectorOptions()
            ).withFaceLandmarks().withFaceDescriptors();
            
            console.log(`Found ${detections.length} face(s)`);
            
            if (detections.length === 0) {
                throw new Error('No face detected. Look at the camera.');
            }
            
            if (detections.length > 1) {
                throw new Error('Multiple faces detected. Only one person should be in frame.');
            }
            
            // Get face data
            const faceData = detections[0].descriptor;
            
            // Convert to regular array (easier to store in database)
            const descriptorArray = Array.from(faceData);
            
            return {
                success: true,
                descriptor: descriptorArray,
                message: 'Face captured successfully!'
            };
            
        } catch (error) {
            console.error('Face capture error:', error);
            return {
                success: false,
                error: error.message,
                message: 'Failed to capture face'
            };
        }
    }

    

    // =========== STOP CAMERA ===========
    static stopCamera() {
        if (this.videoElement && this.videoElement.srcObject) {
            const tracks = this.videoElement.srcObject.getTracks();
            tracks.forEach(track => track.stop());
            this.videoElement.srcObject = null;
            console.log('📸 Camera stopped');
        }
    }

    // =========== VERIFY FACE ===========
    static async verifyFace(storedDescriptor) {
        console.log('🔍 Verifying face...');
        
        if (!this.modelsLoaded) {
            throw new Error('Face recognition models not loaded');
        }


        try {
            // Capture current face
            const result = await this.captureFace();
            if (!result.success) {
                return {
                    success: false,
                    message: result.message
                };
            }
            
            // Convert arrays to Float32Array for comparison
            const currentFace = new Float32Array(result.descriptor);
            const storedFace = new Float32Array(storedDescriptor);
            
            // Calculate similarity (lower distance = more similar)
            const distance = faceapi.euclideanDistance(currentFace, storedFace);
            
            // Check if match (distance < 0.6 means it's the same person)
            const isMatch = distance < 0.6;
            const confidence = Math.max(0, 100 - (distance * 100));
            
            console.log(`Distance: ${distance.toFixed(4)}, Match: ${isMatch}, Confidence: ${confidence.toFixed(1)}%`);
            
            return {
                success: true,
                isMatch: isMatch,
                distance: distance,
                confidence: confidence,
                message: isMatch ? 'Face verified successfully!' : 'Face does not match'
            };
            
        } catch (error) {
            console.error('Face verification error:', error);
            return {
                success: false,
                message: 'Face verification failed'
            };
        }
    }

    
}

// Make it available globally
window.FaceRecognition = FaceRecognition;
console.log('👤 FaceRecognition helper loaded');