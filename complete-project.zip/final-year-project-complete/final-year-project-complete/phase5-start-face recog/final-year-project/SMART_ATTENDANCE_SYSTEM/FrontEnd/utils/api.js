// =========== API UTILITY CLASS ===========
// Using XMLHttpRequest instead of fetch

class API {
    static BASE_URL = 'http://localhost:3000/api';
    static token = null;
    static user = null;

    // =========== XMLHttpRequest WRAPPER ===========
    static request(method, endpoint, data = null, useToken = true) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const url = `${this.BASE_URL}${endpoint}`;
            
            xhr.open(method, url, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            
            if (useToken && this.token) {
                xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
            }
            
            xhr.timeout = 10000; // 10 second timeout
            
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    try {
                        const response = xhr.responseText ? JSON.parse(xhr.responseText) : {};
                        console.log(`✅ API ${method} ${endpoint}:`, response);
                        resolve(response);
                    } catch (e) {
                        console.error('❌ JSON parse error:', e);
                        resolve(xhr.responseText);
                    }
                } else {
                    console.error(`❌ API ${method} ${endpoint} failed:`, xhr.status, xhr.statusText);
                    reject(new Error(`Request failed: ${xhr.status} ${xhr.statusText}`));
                }
            };
            
            xhr.onerror = function() {
                console.error(`❌ Network error: ${method} ${endpoint}`);
                reject(new Error('Network error occurred'));
            };
            
            xhr.ontimeout = function() {
                console.error(`⏰ Timeout: ${method} ${endpoint}`);
                reject(new Error('Request timeout'));
            };
            
            xhr.send(data ? JSON.stringify(data) : null);
        });
    }

    // =========== AUTH METHODS ===========
    static async login(email, password) {
        try {
            const response = await this.request('POST', '/auth/login', { email, password }, false);
            
            if (response.success) {
                this.token = response.token;
                this.user = response.employee;
                
                // Store in localStorage for persistence
                localStorage.setItem('attendance_token', this.token);
                localStorage.setItem('attendance_user', JSON.stringify(this.user));
                
                console.log('✅ Login successful:', this.user.name);
                return { success: true, data: response };
            } else {
                console.log('❌ Login failed:', response.message);
                return { success: false, message: response.message };
            }
        } catch (error) {
            console.error('🔥 Login error:', error);
            return { success: false, message: 'Network error. Please check server connection.' };
        }
    }

    // =========== CHANGE PASSWORD ===========
static async changePassword(currentPassword, newPassword) {
    try {
        const response = await this.request('PUT', '/auth/change-password', {
            currentPassword,
            newPassword
        });
        return response;
    } catch (error) {
        console.error('Change password error:', error);
        return { 
            success: false, 
            message: 'Failed to change password. Check connection.' 
        };
    }
}

    static async logout() {
        try {
            const response = await this.request('POST', '/auth/logout');
            
            // Clear local storage
            this.token = null;
            this.user = null;
            localStorage.removeItem('attendance_token');
            localStorage.removeItem('attendance_user');
            
            console.log('✅ Logout successful');
            return { success: true };
        } catch (error) {
            console.error('Logout error:', error);
            // Still clear local data even if API call fails
            this.token = null;
            this.user = null;
            localStorage.clear();
            return { success: true }; // Consider it successful for UX
        }
    }

    static async getProfile() {
        try {
            const response = await this.request('GET', '/auth/profile');
            return response;
        } catch (error) {
            console.error('Profile error:', error);
            return { success: false, message: 'Failed to load profile' };
        }
    }

    // =========== CHECK IF USER IS LOGGED IN ===========
    static isLoggedIn() {
        // Check memory first, then localStorage
        if (this.token && this.user) {
            return true;
        }
        
        // Try to restore from localStorage
        const savedToken = localStorage.getItem('attendance_token');
        const savedUser = localStorage.getItem('attendance_user');
        
        if (savedToken && savedUser) {
            try {
                this.token = savedToken;
                this.user = JSON.parse(savedUser);
                return true;
            } catch (e) {
                console.error('Failed to parse saved user:', e);
                this.clearAuth();
                return false;
            }
        }
        
        return false;
    }

    static async checkOut() {
    try {
        const response = await this.request('POST', '/attendance/checkout');
        return response;
    } catch (error) {
        console.error('Check-out error:', error);
        return { success: false, message: 'Failed to check out' };
    }
}

    // =========== CLEAR AUTHENTICATION ===========
    static clearAuth() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('attendance_token');
        localStorage.removeItem('attendance_user');
    }

        // =========== FACE VERIFICATION ===========
    static async verifyFace(employeeId, faceDescriptor) {
        try {
            const response = await this.request('POST', '/face/verify', {
                employee_id: employeeId,
                face_descriptor: faceDescriptor
            });
            return response;
        } catch (error) {
            console.error('Face verification error:', error);
            return { 
                success: false, 
                message: 'Face verification failed' 
            };
        }
    }

    // =========== ATTENDANCE METHODS ===========
    static async markAttendance(data) {
        try {
            const response = await this.request('POST', '/attendance/mark', data);
            return response;
        } catch (error) {
            console.error('Mark attendance error:', error);
            return { success: false, message: 'Failed to mark attendance' };
        }
    }

    static async getTodayAttendance() {
        try {
            const response = await this.request('GET', '/attendance/today');
            return response;
        } catch (error) {
            console.error('Get today attendance error:', error);
            return { success: false, message: 'Failed to get today\'s attendance' };
        }
    }

    static async getAttendanceStats() {
        try {
            const response = await this.request('GET', '/attendance/stats');
            return response;
        } catch (error) {
            console.error('Get stats error:', error);
            return { success: false, message: 'Failed to get attendance statistics' };
        }
    }

    static async getAttendanceHistory(startDate = null, endDate = null) {
        try {
            let endpoint = '/attendance/history';
            
            if (startDate || endDate) {
                const params = new URLSearchParams();
                if (startDate) params.append('startDate', startDate);
                if (endDate) params.append('endDate', endDate);
                endpoint += `?${params.toString()}`;
            }
            
            const response = await this.request('GET', endpoint);
            return response;
        } catch (error) {
            console.error('Get history error:', error);
            return { success: false, message: 'Failed to load attendance history' };
        }
    }

    // =========== TEST CONNECTION ===========
    static async testConnection() {
        try {
            const response = await this.request('GET', '/health', null, false);
            return response.success === true;
        } catch (error) {
            console.error('Server connection test failed:', error);
            return false;
        }
    }

    // =========== GET HEADERS ===========
    static getHeaders() {
        const headers = {
            'Content-Type': 'application/json'
        };
        
        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }
        
        return headers;
    }

    // =========== ADMIN METHODS (if needed later) ===========
    static async getAdminStats() {
        try {
            const response = await this.request('GET', '/admin/dashboard/stats');
            return response;
        } catch (error) {
            console.error('Get admin stats error:', error);
            return { success: false, message: 'Admin access required' };
        }
    }

    // =========== ADMIN METHODS ===========
// =========== ADMIN METHODS ===========
static async registerEmployee(employeeData) {
    try {
        const response = await this.request('POST', '/face/register-employee', employeeData);
        return response;
    } catch (error) {
        console.error('Register employee error:', error);
        return { 
            success: false, 
            message: 'Failed to register employee. Please check server connection.' 
        };
    }
}

static async updateFace(employeeId, faceDescriptor) {
    try {
        const response = await this.request('POST', '/face/update-face', {
            employee_id: employeeId,
            face_descriptor: faceDescriptor
        });
        return response;
    } catch (error) {
        console.error('Update face error:', error);
        return { 
            success: false, 
            message: 'Failed to update face data' 
        };
    }
}

    static async getEmployees() {
        try {
            const response = await this.request('GET', '/admin/employees');
            return response;
        } catch (error) {
            console.error('Get employees error:', error);
            return { success: false, message: 'Failed to load employees' };
        }
    }

            // =========== ADMIN DASHBOARD STATS ===========
        static async getAdminDashboardStats() {
            try {
                const response = await this.request('GET', '/admin/dashboard-stats');
                return response;
            } catch (error) {
                console.error('Admin dashboard stats error:', error);
                return { 
                    success: false, 
                    message: 'Failed to load dashboard statistics' 
                };
            }
        }
}


