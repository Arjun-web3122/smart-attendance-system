// =========== HELPER FUNCTIONS ===========
class Helpers {
    
    // =========== DOM HELPERS ===========
    static getElement(id) {
        return document.getElementById(id);
    }
    
    static showElement(id) {
        const element = this.getElement(id);
        if (element) element.style.display = 'block';
    }
    
    static hideElement(id) {
        const element = this.getElement(id);
        if (element) element.style.display = 'none';
    }
    
    static showMessage(elementId, message, type = 'error') {
        const element = this.getElement(elementId);
        if (element) {
            element.textContent = message;
            element.className = `message ${type}`;
            this.showElement(elementId);
            
            // Auto hide after 5 seconds for success messages
            if (type === 'success') {
                setTimeout(() => {
                    this.hideElement(elementId);
                }, 5000);
            }
        }
    }
    
    static clearMessage(elementId) {
        const element = this.getElement(elementId);
        if (element) {
            element.textContent = '';
            element.className = 'message';
            this.hideElement(elementId);
        }
    }
    
    // =========== FORMATTING HELPERS ===========
    static formatDate(dateString) {
        if (!dateString) return '--';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    static formatDateTime(dateString) {
        if (!dateString) return '--';
        const date = new Date(dateString);
        return date.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    static formatTime(dateString) {
        if (!dateString) return '--:--';
        const date = new Date(dateString);
        return date.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    static formatDuration(start, end) {
        if (!start || !end) return '--';
        
        const startDate = new Date(start);
        const endDate = new Date(end);
        const diffMs = endDate - startDate;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        
        return `${diffHours}h ${diffMinutes}m`;
    }
    
    // =========== VALIDATION HELPERS ===========
    static isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    static validatePassword(password) {
        if (password.length < 6) {
            return 'Password must be at least 6 characters';
        }
        return null;
    }
    
    // =========== STORAGE HELPERS ===========
    static setItem(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('LocalStorage set error:', e);
        }
    }
    
    static getItem(key) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (e) {
            console.error('LocalStorage get error:', e);
            return null;
        }
    }
    
    static removeItem(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.error('LocalStorage remove error:', e);
        }
    }
    
    // =========== UI STATE HELPERS ===========
    static setLoading(button, isLoading) {
        if (!button) return;
        
        if (isLoading) {
            button.disabled = true;
            const originalText = button.dataset.originalText || button.textContent;
            button.dataset.originalText = originalText;
            button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Loading...`;
        } else {
            button.disabled = false;
            const originalText = button.dataset.originalText;
            if (originalText) {
                button.textContent = originalText;
                delete button.dataset.originalText;
            }
        }
    }
    
    static enableElement(id) {
        const element = this.getElement(id);
        if (element) element.disabled = false;
    }
    
    static disableElement(id) {
        const element = this.getElement(id);
        if (element) element.disabled = true;
    }
    
    // =========== DATE HELPERS ===========
    static getTodayDate() {
        return new Date().toISOString().split('T')[0];
    }
    
    static getCurrentTime() {
        return new Date().toISOString();
    }
    
   // =========== DATE HELPERS ===========
static getStartOfMonth(date = new Date()) {
    const start = new Date(date.getFullYear(), date.getMonth(), 1);
    return start.toISOString().split('T')[0];
}

static getEndOfMonth(date = new Date()) {
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    return end.toISOString().split('T')[0];
}

static getMonthName(date = new Date()) {
    return date.toLocaleDateString('en-US', { month: 'long' });
}

// =========== CALCULATION HELPERS ===========
static calculateWorkHours(checkIn, checkOut) {
    if (!checkIn || !checkOut) return 0;
    
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    return (end - start) / (1000 * 60 * 60); // Return hours
}

static formatWorkHours(hours) {
    if (!hours) return '--';
    const wholeHours = Math.floor(hours);
    const minutes = Math.round((hours - wholeHours) * 60);
    return `${wholeHours}h ${minutes}m`;
}
    
    // =========== LOCATION HELPERS ===========
    static getLocation() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocation not supported by your browser'));
            return;
        }
        
        console.log('📍 Requesting GPS location...');
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const locationData = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    accuracy: position.coords.accuracy, // In meters
                    altitude: position.coords.altitude,
                    altitudeAccuracy: position.coords.altitudeAccuracy,
                    heading: position.coords.heading,
                    speed: position.coords.speed,
                    timestamp: new Date(position.timestamp)
                };
                
                console.log('📍 GPS obtained:', locationData);
                
                // Check accuracy - if too inaccurate, show warning
                if (locationData.accuracy > 100) {
                    console.warn('⚠️ Low GPS accuracy:', locationData.accuracy, 'meters');
                }
                
                resolve(locationData);
            },
            (error) => {
                console.error('📍 GPS error:', error);
                
                let errorMessage = 'Failed to get location';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage = 'Location permission denied. Please enable GPS.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage = 'Location information unavailable.';
                        break;
                    case error.TIMEOUT:
                        errorMessage = 'Location request timed out.';
                        break;
                }
                
                reject(new Error(errorMessage));
            },
            {
                enableHighAccuracy: true,    // Try to get best accuracy
                timeout: 15000,              // 15 seconds max
                maximumAge: 0                // Don't use cached location
            }
        );
    });
}
    
    static calculateDistance(lat1, lon1, lat2, lon2) {
        // Haversine formula
        const R = 6371000; // Earth radius in meters
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const Δφ = (lat2 - lat1) * Math.PI / 180;
        const Δλ = (lon2 - lon1) * Math.PI / 180;
        
        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        
        return R * c; // Distance in meters
    }
    
    // =========== CAMERA HELPERS ===========
    static async getCameraStream() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    facingMode: 'user',
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                },
                audio: false
            });
            return stream;
        } catch (error) {
            console.error('Camera error:', error);
            throw error;
        }
    }
    
    // =========== STRING HELPERS ===========
    static capitalizeFirstLetter(string) {
        if (!string) return '';
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    
    static truncateString(str, maxLength = 50) {
        if (!str) return '';
        if (str.length <= maxLength) return str;
        return str.substring(0, maxLength) + '...';
    }
    
    // =========== DEBOUNCE HELPERS ===========
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    

    
}