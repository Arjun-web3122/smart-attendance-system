// =========== MAIN APPLICATION SCRIPT ===========
let dashboardInterval = null;

//gpt
let faceVerificationResult = {
    verified: false,
    confidence: 0
};


// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Smart Attendance System Frontend loaded');
    
    // Initialize the application
    initApp();
});

// =========== APPLICATION INITIALIZATION ===========
/*
async function initApp() {
    console.log('🔧 Initializing application...');
    
    // Test backend connection on startup
    await testBackendConnection();
    
    // Setup event listeners
    setupEventListeners();
    
    // Check if user is already logged in
    checkExistingLogin();
    
    // Show current version
    console.log('🏁 Application initialized successfully');
}
*/

// =========== BACKEND CONNECTION TEST ===========
async function testBackendConnection() {
    try {
        const isConnected = await API.testConnection();
        if (isConnected) {
            console.log('✅ Backend connection: OK');
        } else {
            console.warn('⚠️ Backend connection: Failed');
            Helpers.showMessage('loginMessage', 
                'Cannot connect to server. Make sure backend is running on http://localhost:3000', 
                'error');
        }
    } catch (error) {
        console.error('❌ Backend test error:', error);
    }
}


//added
// Update last update time
function updateLastUpdateTime() {
    const lastUpdateElement = Helpers.getElement('lastUpdateTime');
    if (lastUpdateElement) {
        const now = new Date();
        const timeString = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        lastUpdateElement.innerHTML = `<i class="fas fa-sync-alt"></i> Updated at ${timeString}`;
        
        // Add animation
        lastUpdateElement.style.animation = 'none';
        setTimeout(() => {
            lastUpdateElement.style.animation = 'pulse 0.5s';
        }, 10);
    }
}

// =========== EVENT LISTENERS SETUP ===========
function setupEventListeners() {
    console.log('🔗 Setting up event listeners...');
    
    // Login form submission
    const loginForm = Helpers.getElement('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
        console.log('✅ Login form listener added');
    }
    
    // Show/Hide password button
    const showPasswordBtn = Helpers.getElement('showPassword');
    if (showPasswordBtn) {
        showPasswordBtn.addEventListener('click', togglePasswordVisibility);
    }
    
    // Logout button
    const logoutBtn = Helpers.getElement('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Navigation menu items
    const navItems = document.querySelectorAll('.nav-item[data-page]');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            navigateToPage(page);
            
            // Update active state
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Quick action buttons
    const quickCheckInBtn = Helpers.getElement('quickCheckIn');
    if (quickCheckInBtn) {
        quickCheckInBtn.addEventListener('click', () => navigateToPage('attendance'));
    }
    
    const quickCheckOutBtn = Helpers.getElement('quickCheckOut');
    if (quickCheckOutBtn) {
        quickCheckOutBtn.addEventListener('click', handleQuickCheckOut);
    }
    
    const viewTodayBtn = Helpers.getElement('viewToday');
    if (viewTodayBtn) {
        viewTodayBtn.addEventListener('click', () => {
            navigateToPage('history');
            // TODO: Filter to show only today's records
        });
    }
    
    // Attendance page buttons
    const checkLocationBtn = Helpers.getElement('checkLocationBtn');
    if (checkLocationBtn) {
        checkLocationBtn.addEventListener('click', handleLocationCheck);
    }
    
    const checkFaceBtn = Helpers.getElement('checkFaceBtn');
    if (checkFaceBtn) {
        checkFaceBtn.addEventListener('click', handleFaceCheck);
    }
    
    const submitAttendanceBtn = Helpers.getElement('submitAttendanceBtn');
    if (submitAttendanceBtn) {
        submitAttendanceBtn.addEventListener('click', handleSubmitAttendance);
    }
    
    // History page buttons
    const loadHistoryBtn = Helpers.getElement('loadHistoryBtn');
    if (loadHistoryBtn) {
        loadHistoryBtn.addEventListener('click', loadAttendanceHistory);
    }
    
    const filterHistoryBtn = Helpers.getElement('filterHistory');
    if (filterHistoryBtn) {
        filterHistoryBtn.addEventListener('click', loadAttendanceHistory);
    }
    
    const resetFilterBtn = Helpers.getElement('resetFilter');
    if (resetFilterBtn) {
        resetFilterBtn.addEventListener('click', resetHistoryFilter);
    }


    // Edit form submission
    const editForm = document.getElementById('editEmployeeForm');
    if (editForm) {
        editForm.addEventListener('submit', handleEditFormSubmit);
    }
    
    // Close modal when clicking outside
    const editModal = document.getElementById('editEmployeeModal');
    if (editModal) {
        editModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditModal();
            }
        });
    }
    
   

        // Export button
    const exportHistoryBtn = Helpers.getElement('exportHistory');
    if (exportHistoryBtn) {
        exportHistoryBtn.addEventListener('click', exportAttendanceHistory);
    }

    // Refresh dashboard button
        const refreshDashboardBtn = Helpers.getElement('refreshDashboard');
        if (refreshDashboardBtn) {
            refreshDashboardBtn.addEventListener('click', () => {
                loadDashboardData();
                loadRecentActivity();
            });
        }


        // Change password button
    const changePasswordBtn = Helpers.getElement('changePasswordBtn');
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', openChangePasswordModal);
    }
    
    // Password form submission
    const passwordForm = Helpers.getElement('changePasswordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', handlePasswordChange);
    }
    
    // Setup face button
    const setupFaceBtn = Helpers.getElement('setupFaceBtn');
    if (setupFaceBtn) {
        setupFaceBtn.addEventListener('click', () => {
            alert('Face setup requires admin registration.\nContact your administrator.');
        });
    }
    
    // Close modal when clicking outside
    const modal = Helpers.getElement('changePasswordModal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closePasswordModal();
            }
        });
    }


       

    
    console.log('✅ All event listeners added');
}

// =========== CHECK EXISTING LOGIN ===========
function checkExistingLogin() {
    if (API.isLoggedIn()) {
        console.log('👤 User already logged in:', API.user.name);
        showDashboard();
        loadUserProfile();
    } else {
        console.log('👋 No existing login found');
        showLoginScreen();
    }
}

// =========== LOGIN HANDLER ===========
async function handleLogin(event) {
    event.preventDefault();
    console.log('🔐 Handling login...');
    
    const email = Helpers.getElement('email').value.trim();
    const password = Helpers.getElement('password').value;
    const loginBtn =
        event.target.querySelector('.btn-login') ||
        Helpers.getElement('loginForm').querySelector('.btn-login');

    // Basic validation
    if (!email || !password) {
        Helpers.showMessage('loginMessage', 'Please enter both email and password', 'error');
        return;
    }

    if (!Helpers.isValidEmail(email)) {
        Helpers.showMessage('loginMessage', 'Please enter a valid email address', 'error');
        return;
    }

    // Show loading state
    Helpers.setLoading(loginBtn, true);
    Helpers.clearMessage('loginMessage');

    try {
        // 🔐 Call API login
        const result = await API.login(email, password);

        if (result.success) {
            Helpers.showMessage(
                'loginMessage',
                'Login successful! Redirecting...',
                'success'
            );

            // 🔥 FIX #2 — HARD RESET BEFORE NEW USER LOAD
            //resetDashboardUI();      // clears stats, avg hours, tables
            //clearCheckInOutUI();     // removes old checkout time DOM
            loadRecentActivity?.();  // optional: ensure clean slate

            // Small delay to show success message
            setTimeout(() => {
                showDashboard();     // show dashboard
                loadUserProfile();   // load NEW user only
            }, 500);

        } else {
            Helpers.showMessage(
                'loginMessage',
                result.message || 'Login failed. Please check credentials.',
                'error'
            );
        }
    } catch (error) {
        console.error('Login error:', error);
        Helpers.showMessage(
            'loginMessage',
            'Network error. Please check server connection.',
            'error'
        );
    } finally {
        // Reset loading state
        Helpers.setLoading(loginBtn, false);
    }
}


// =========== LOGOUT HANDLER ===========
async function handleLogout() {
    console.log('👋 Logging out...');

    // 🛑 STOP dashboard auto-refresh
    if (dashboardInterval) {
        clearInterval(dashboardInterval);
        dashboardInterval = null;
    }

    try {
        await API.checkOut().catch(() => {});
        await API.logout();

        clearAllCachedData();
        resetDashboardUI();
        showLoginScreen();

    } catch (error) {
        clearAllCachedData();
        showLoginScreen();
    }
}

// =========== CLEAR ALL CACHED DATA ===========
function clearAllCachedData() {
    console.log('🧹 Clearing all cached data...');
    
    // Clear API cache
    API.clearAuth();
    
    // Clear localStorage
    localStorage.removeItem('attendance_token');
    localStorage.removeItem('attendance_user');
    localStorage.removeItem('dashboard_data');
    localStorage.removeItem('attendance_history');
    
    // Clear any other cached data
    Object.keys(localStorage).forEach(key => {
        if (key.startsWith('attendance_') || key.startsWith('dashboard_')) {
            localStorage.removeItem(key);
        }
    });
    
    // Clear sessionStorage
    sessionStorage.clear();
}




// =========== RESET DASHBOARD UI ===========
function resetDashboardUI() {
    console.log('🔄 Resetting UI...');
    const checkOutTimeEl = Helpers.getElement('checkOutTime');
    if (checkOutTimeEl) {
        checkOutTimeEl.textContent = 'Out: --:--';
        checkOutTimeEl.style.display = 'none';
    }


    

    const resetElements = [
        'todayStatus','monthDays','attendanceRate',
        'officeDistance',
        'profileName','profileEmail','profileEmployeeId'
    ];

    resetElements.forEach(id => {
        const el = Helpers.getElement(id);
        if (el) el.textContent = '--';
    });

    // 🔥 REMOVE avg hours explicitly
    const avg = Helpers.getElement('avgWorkHours');
    if (avg) avg.remove();

    Helpers.getElement('attendanceTableBody')?.replaceChildren();
    Helpers.getElement('recentActivityList')?.replaceChildren();
}


// =========== TOGGLE PASSWORD VISIBILITY ===========
function togglePasswordVisibility() {
    const passwordInput = Helpers.getElement('password');
    const eyeIcon = this.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.className = 'fas fa-eye-slash';
        this.title = 'Hide password';
    } else {
        passwordInput.type = 'password';
        eyeIcon.className = 'fas fa-eye';
        this.title = 'Show password';
    }
}

// =========== SHOW/HIDE SCREENS ===========
function showLoginScreen() {
    console.log('🖥️ Showing login screen');
    Helpers.hideElement('dashboardContainer');
    Helpers.showElement('loginContainer');
}

function showDashboard() {
    console.log('📊 Showing dashboard');
    Helpers.hideElement('loginContainer');
    Helpers.showElement('dashboardContainer');
    
    // Show home page by default
    navigateToPage('home');
}

/*
// =========== PAGE NAVIGATION ===========
function navigateToPage(page) {
    console.log(`📄 Navigating to page: ${page}`);
    
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(p => {
        p.classList.remove('active');
        p.style.display = 'none';
    });
    
    // Show selected page
    const targetPage = Helpers.getElement(`page${page.charAt(0).toUpperCase() + page.slice(1)}`);
    if (targetPage) {
        targetPage.style.display = 'block';
        targetPage.classList.add('active');
        
        // Load data for specific pages
        switch(page) {
            case 'home':
                loadDashboardData();
                break;
            case 'history':
                loadAttendanceHistory();
                break;
            case 'profile':
                loadProfileData();
                break;
        }
    }
}
    */
// =========== AUTO-REFRESH TODAY STATUS ===========
let dashboardRefreshInterval = null;
/*
function startDashboardAutoRefresh() {
    // Clear any existing interval
    if (dashboardRefreshInterval) {
        clearInterval(dashboardRefreshInterval);
        dashboardRefreshInterval = null;
    }
    
    // Only refresh if user is on dashboard page
    const isOnDashboard = Helpers.getElement('pageHome') && 
                         Helpers.getElement('pageHome').style.display !== 'none';
    
    if (API.isLoggedIn() && isOnDashboard) {
        console.log('🔄 Starting dashboard auto-refresh (30 seconds)...');
        
        dashboardRefreshInterval = setInterval(async () => {
            try {
                console.log('🔄 Auto-refreshing today status...');
                await loadTodayStatus();
                await loadRecentActivity();
            } catch (error) {
                console.error('Auto-refresh error:', error);
            }
        }, 30000); // 30 seconds
    }
}
*/
function startDashboardAutoRefresh() {
    stopDashboardAutoRefresh();

    if (!API.isLoggedIn()) return;

    dashboardRefreshInterval = setInterval(() => {
        loadTodayStatus();
    }, 30000);
}

// Stop auto-refresh when leaving dashboard
function stopDashboardAutoRefresh() {
    if (dashboardRefreshInterval) {
        clearInterval(dashboardRefreshInterval);
        dashboardRefreshInterval = null;
        console.log('🛑 Stopped dashboard auto-refresh');
    }
}
// =========== PAGE NAVIGATION ===========
function navigateToPage(page) {
    console.log(`📄 Navigating to page: ${page}`);
    
    // Stop auto-refresh when leaving dashboard
    if (page !== 'home') {
        stopDashboardAutoRefresh();
    }
    
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(p => {
        p.classList.remove('active');
        p.style.display = 'none';
    });
    
    // Show selected page
    const targetPage = Helpers.getElement(`page${page.charAt(0).toUpperCase() + page.slice(1)}`);
    if (targetPage) {
        targetPage.style.display = 'block';
        targetPage.classList.add('active');
        
        // Load data for specific pages
        switch(page) {
            case 'home':
                loadDashboardData(); // This will start auto-refresh
                break;
            case 'history':
                loadAttendanceHistory();
                break;
            case 'profile':
                loadProfileData();
                break;
        }
    }
}

// =========== LOAD USER PROFILE ===========
async function loadUserProfile() {
    if (!API.user) return;
    
    console.log('👤 Loading user profile...');
    
    // Update UI with user info from API
    Helpers.getElement('userName').textContent = API.user.name;
    Helpers.getElement('userEmail').textContent = API.user.email;
    Helpers.getElement('employeeId').textContent = API.user.employee_id;
    Helpers.getElement('navUser').querySelector('span').textContent = API.user.name;
    
    // Also update profile page
    Helpers.getElement('profileName').textContent = API.user.name;
    Helpers.getElement('profileEmail').textContent = API.user.email;
    Helpers.getElement('profileEmployeeId').textContent = API.user.employee_id;
    
    // Try to get fresh profile data from API
    try {
        const profileResponse = await API.getProfile();
        if (profileResponse.success) {
            const employee = profileResponse.employee;
            
            // Update with fresh data
            Helpers.getElement('detailEmployeeId').textContent = employee.employee_id;
            Helpers.getElement('detailFullName').textContent = employee.name;
            Helpers.getElement('detailEmail').textContent = employee.email;
            Helpers.getElement('detailCreatedAt').textContent = Helpers.formatDate(employee.created_at);
            Helpers.getElement('detailLastLogin').textContent = employee.last_login ? Helpers.formatDateTime(employee.last_login) : 'Never';
            
            // Face recognition status
            const faceRecognitionElement = Helpers.getElement('detailFaceRecognition');
            if (employee.has_face_encoding) {
                faceRecognitionElement.innerHTML = '<span class="status-badge configured">Configured</span>';
            } else {
                faceRecognitionElement.innerHTML = '<span class="status-badge not-configured">Not Configured</span>';
            }
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

// =========== LOAD ATTENDANCE HISTORY (REAL DATA) ===========
async function loadAttendanceHistory() {
    console.log('📅 Loading REAL attendance history...');
    
    if (!API.user) {
        console.error('No user logged in');
        return;
    }
    
    // Get filter values
    const startDate = Helpers.getElement('startDate')?.value || null;
    const endDate = Helpers.getElement('endDate')?.value || null;
    
    // Show loading state
    const loadingContainer = Helpers.getElement('historyLoading');
    const tableBody = Helpers.getElement('attendanceTableBody');
    const tableContainer = Helpers.getElement('historyTableContainer');
    
    if (loadingContainer) loadingContainer.style.display = 'block';
    if (tableContainer) tableContainer.style.display = 'none';
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 40px;">
                    <i class="fas fa-spinner fa-spin"></i> Loading...
                </td>
            </tr>
        `;
    }
    
    try {
        console.log('📊 Fetching history with params:', { startDate, endDate });
        
        // Call REAL API
        const response = await API.getAttendanceHistory(startDate, endDate);
        
        console.log('History API response:', response);
        
        if (response.success && response.history && Array.isArray(response.history)) {
            displayAttendanceHistory(response.history);
            calculateHistoryStats(response.history);
        } else {
            displayNoHistoryMessage();
        }
        
    } catch (error) {
        console.error('❌ Error loading history:', error);
        
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align: center; padding: 40px; color: #f44336;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error loading attendance history</p>
                        <button onclick="loadAttendanceHistory()" style="margin-top: 10px; padding: 8px 15px; background: #f44336; color: white; border: none; border-radius: 5px;">
                            <i class="fas fa-redo"></i> Try Again
                        </button>
                    </td>
                </tr>
            `;
        }
    } finally {
        if (loadingContainer) loadingContainer.style.display = 'none';
        if (tableContainer) tableContainer.style.display = 'block';
    }
}

// =========== DISPLAY ATTENDANCE HISTORY ===========
function displayAttendanceHistory(history) {
    console.log('DEBUG: Received history:', history);
    
    const tableBody = Helpers.getElement('attendanceTableBody');
    
    if (!tableBody) return;
    
    if (!history || history.length === 0) {
        displayNoHistoryMessage();
        return;
    }
    
    console.log(`Displaying ${history.length} records`);
    
    let html = '';
    
    history.forEach((record, index) => {
        console.log(`Record ${index}:`, record);
        
        // Date formatting
        const date = new Date(record.check_in);
        const dateString = Helpers.formatDate(record.check_in);
        const checkInTime = Helpers.formatTime(record.check_in);
        const checkOutTime = record.check_out ? Helpers.formatTime(record.check_out) : '--:--';
        
        // Calculate work hours
        let workHours = '--';
        if (record.check_in && record.check_out) {
            const start = new Date(record.check_in);
            const end = new Date(record.check_out);
            const diffMs = end - start;
            const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
            const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
            workHours = `${diffHours}h ${diffMinutes}m`;
        }
        
        // Status indicator
        let status = 'Present';
        let statusClass = 'status-present';
        
        if (!record.check_out) {
            status = 'Active';
            statusClass = 'status-active';
        }
        
        // GPS location - FIXED FOR STRINGS
        let gpsInfo = 'No GPS';
        if (record.gps_lat && record.gps_lng) {
            try {
                // Convert strings to numbers
                const lat = parseFloat(record.gps_lat);
                const lng = parseFloat(record.gps_lng);
                
                if (!isNaN(lat) && !isNaN(lng)) {
                    gpsInfo = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                } else {
                    gpsInfo = 'Invalid GPS data';
                }
            } catch (error) {
                console.error('GPS parsing error:', error);
                gpsInfo = 'GPS parse error';
            }
        }
        
        // Face verification status
        const faceStatus = record.face_verified 
            ? '<i class="fas fa-check-circle" style="color: #4CAF50;" title="Face Verified"></i>' 
            : '<i class="fas fa-times-circle" style="color: #f44336;" title="Face Not Verified"></i>';
        
        // Location verification status
        const locationStatus = record.location_verified 
            ? '<i class="fas fa-check-circle" style="color: #4CAF50;" title="Location Verified"></i>' 
            : '<i class="fas fa-times-circle" style="color: #f44336;" title="Location Not Verified"></i>';
        
        // Row HTML
        html += `
            <tr>
                <td>
                    <strong>${dateString}</strong><br>
                    <small>${date.toLocaleDateString('en-US', { weekday: 'long' })}</small>
                </td>
                <td>${checkInTime}</td>
                <td>${checkOutTime}</td>
                <td>${workHours}</td>
                <td>
                    <i class="fas fa-map-marker-alt" style="color: #2196F3;"></i>
                    <small style="display: block; font-size: 12px; margin-top: 5px;">${gpsInfo}</small>
                </td>
                <td style="text-align: center;">${faceStatus}</td>
                <td style="text-align: center;">${locationStatus}</td>
                <td>
                    <span class="status-badge ${statusClass}">${status}</span>
                </td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html;
    console.log('✅ History displayed successfully');
    
    // Calculate statistics
    calculateHistoryStats(history);
}
// =========== DISPLAY NO HISTORY MESSAGE ===========
function displayNoHistoryMessage() {
    const tableBody = Helpers.getElement('attendanceTableBody');
    
    if (tableBody) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-message">
                    <i class="fas fa-history" style="font-size: 48px; color: #ccc; margin-bottom: 10px;"></i>
                    <h3>No attendance records found</h3>
                    <p>Your attendance history will appear here once you start marking attendance.</p>
                    <button id="goToAttendanceBtn" style="margin-top: 15px; padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
                        <i class="fas fa-calendar-check"></i> Mark First Attendance
                    </button>
                </td>
            </tr>
        `;
        
        // Add event listener to the button
        const goToAttendanceBtn = Helpers.getElement('goToAttendanceBtn');
        if (goToAttendanceBtn) {
            goToAttendanceBtn.addEventListener('click', () => navigateToPage('attendance'));
        }
    }
}

// =========== CALCULATE HISTORY STATISTICS ===========
function calculateHistoryStats(history) {
    if (!history || history.length === 0) {
        Helpers.getElement('totalDays').textContent = '0 days';
        Helpers.getElement('avgHours').textContent = '0 hours';
        Helpers.getElement('attendanceRate2').textContent = '0%';
        return;
    }
    
    // Calculate total days
    const totalDays = history.length;
    
    // Calculate average work hours
    let totalHours = 0;
    let daysWithCheckout = 0;
    
    history.forEach(record => {
        if (record.check_in && record.check_out) {
            const start = new Date(record.check_in);
            const end = new Date(record.check_out);
            const diffHours = (end - start) / (1000 * 60 * 60);
            totalHours += diffHours;
            daysWithCheckout++;
        }
    });
    
    const avgHours = daysWithCheckout > 0 ? totalHours / daysWithCheckout : 0;
    
    // Calculate attendance rate (days with check-in vs total days in month)
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    
    // Count days with attendance this month
    const daysWithAttendance = history.filter(record => {
        const recordDate = new Date(record.check_in);
        return recordDate.getMonth() === currentMonth && recordDate.getFullYear() === currentYear;
    }).length;
    
    const attendanceRate = Math.round((daysWithAttendance / daysInMonth) * 100);
    
    // Update UI
    Helpers.getElement('totalDays').textContent = `${totalDays} days`;
    Helpers.getElement('avgHours').textContent = `${avgHours.toFixed(1)} hours`;
    Helpers.getElement('attendanceRate2').textContent = `${attendanceRate}%`;
}

// =========== ENHANCED DASHBOARD DATA LOADING ===========
/*
async function loadDashboardData() {
    console.log('📈 Loading ENHANCED dashboard data...');
    
    if (!API.user) return;
    
    
    try {
        // Show loading state
        const dashboardElements = [
            'todayStatus', 'checkInTime', 'monthDays', 
            'attendanceRate', 'officeDistance'
        ];
        
        dashboardElements.forEach(id => {
            const element = Helpers.getElement(id);
            if (element) {
                element.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            }
        });
        
        // 1. Get today's attendance status
        await loadTodayStatus();
        
        // 2. Get monthly statistics
        await loadMonthlyStats();
        
        // 3. Get GPS distance (optional)
        await loadGPSDistance();
        
        // 4. Get attendance streak
       // await loadAttendanceStreak();
        
        console.log('✅ Dashboard data loaded successfully');
        
    } catch (error) {
        console.error('❌ Error loading dashboard data:', error);
        
        // Show error states
        Helpers.getElement('todayStatus').textContent = 'Error loading';
        Helpers.getElement('todayStatus').style.color = '#f44336';
    }
}

async function loadDashboardData() {
    console.log('📈 Loading ENHANCED dashboard data...');
    
    if (!API.user) return;
    
    try {
        // Load all dashboard data in parallel
        await Promise.all([
            loadTodayStatus(),
            loadMonthlyStats(),
            loadGPSDistance(),
            loadRecentActivity()
        ]);
        
        console.log('✅ Dashboard data loaded successfully');
        
    } catch (error) {
        console.error('❌ Error loading dashboard data:', error);
        
        // Show error states
        const todayStatusEl = Helpers.getElement('todayStatus');
        if (todayStatusEl) {
            todayStatusEl.textContent = 'Error loading';
            todayStatusEl.style.color = '#f44336';
        }
    }
}
    */
   // =========== LOAD DASHBOARD DATA (SIMPLIFIED) ===========
async function loadDashboardData() {
    console.log('📊 Loading dashboard data...');
    
    if (!API.user) {
        console.log('No user logged in, skipping dashboard load');
        return;
    }
    
    try {
        // Show loading state
        Helpers.getElement('todayStatus').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        Helpers.getElement('checkInTime').textContent = '--:--';
        
        // Load data in sequence (not parallel for better debugging)
        console.log('1. Loading today status...');
        await loadTodayStatus();
        
        console.log('2. Loading monthly stats...');
        await loadMonthlyStats();
        
        console.log('3. Loading GPS distance...');
        await loadGPSDistance();
        
        console.log('4. Loading recent activity...');
        await loadRecentActivity();
        
        console.log('✅ Dashboard data loaded successfully');
        
        // Start auto-refresh
        startDashboardAutoRefresh();
        
    } catch (error) {
        console.error('❌ Error loading dashboard data:', error);
        Helpers.getElement('todayStatus').textContent = 'Error loading';
        Helpers.getElement('todayStatus').style.color = '#f44336';
    }
}

/*

// =========== TODAY'S STATUS ===========
async function loadTodayStatus() {
    try {
        const response = await API.getTodayAttendance();

        const todayStatusEl = Helpers.getElement('todayStatus');
        const checkInEl = Helpers.getElement('checkInTime');
        const checkOutEl = Helpers.getElement('checkOutTime');

        if (response.success && response.attendance) {
            const a = response.attendance;

            // ✅ CHECKED IN but NOT CHECKED OUT
            if (a.check_in && !a.check_out) {
                todayStatusEl.innerHTML = 'Checked In <i class="fas fa-check-circle"></i>';
                todayStatusEl.style.color = '#4CAF50';

                checkInEl.textContent = Helpers.formatTime(a.check_in);
                checkInEl.style.color = '#4CAF50';

                checkOutEl.textContent = 'Out: --:--';
                checkOutEl.style.display = 'block';
            }

            // ✅ CHECKED OUT
            else if (a.check_in && a.check_out) {
                todayStatusEl.innerHTML = 'Checked Out <i class="fas fa-sign-out-alt"></i>';
                todayStatusEl.style.color = '#FF9800';

                checkInEl.textContent = Helpers.formatTime(a.check_in);
                checkInEl.style.color = '#FF9800';

                checkOutEl.textContent = `Out: ${Helpers.formatTime(a.check_out)}`;
                checkOutEl.style.display = 'block';
            }

            // ✅ NOT CHECKED IN
            else {
                todayStatusEl.innerHTML = 'Not Checked In <i class="fas fa-clock"></i>';
                todayStatusEl.style.color = '#f44336';

                checkInEl.textContent = '--:--';
                checkInEl.style.color = '#666';

                checkOutEl.textContent = 'Out: --:--';
                checkOutEl.style.display = 'block';
            }
        } else {
            // No attendance record today
            todayStatusEl.innerHTML = 'Not Checked In <i class="fas fa-clock"></i>';
            todayStatusEl.style.color = '#f44336';

            checkInEl.textContent = '--:--';
            checkOutEl.textContent = 'Out: --:--';
            checkOutEl.style.display = 'block';
        }

    } catch (error) {
        console.error('Error loading today status:', error);
        Helpers.getElement('todayStatus').textContent = 'Error';
        Helpers.getElement('todayStatus').style.color = '#f44336';
    }
}


// =========== TODAY'S STATUS WITH REAL-TIME UPDATES ===========
async function loadTodayStatus() {
    try {
        const response = await API.getTodayAttendance();
        console.log('Today status response:', response);

        const todayStatusEl = Helpers.getElement('todayStatus');
        const checkInEl = Helpers.getElement('checkInTime');
        const checkOutEl = Helpers.getElement('checkOutTime');

        // Clear previous content
        todayStatusEl.innerHTML = '';
        todayStatusEl.style.color = '';
        checkInEl.textContent = '--:--';
        checkInEl.style.color = '#666';
        
        // Ensure checkout element exists and is visible
        if (!checkOutEl) {
            // Create checkout element if it doesn't exist
            const checkOutDiv = document.createElement('div');
            checkOutDiv.id = 'checkOutTime';
            checkOutDiv.className = 'checkout-time';
            checkInEl.parentNode.appendChild(checkOutDiv);
            checkOutEl = checkOutDiv;
        }
        
        checkOutEl.textContent = 'Out: --:--';
        checkOutEl.style.display = 'block';

        if (response.success && response.attendance) {
            const a = response.attendance;
            console.log('Attendance record found:', a);

            // ✅ CHECKED IN but NOT CHECKED OUT
            if (a.check_in && !a.check_out) {
                todayStatusEl.innerHTML = 'Checked In <i class="fas fa-check-circle"></i>';
                todayStatusEl.style.color = '#4CAF50';

                checkInEl.textContent = Helpers.formatTime(a.check_in);
                checkInEl.style.color = '#4CAF50';

                checkOutEl.textContent = 'Out: --:--';
                checkOutEl.style.color = '#666';
                checkOutEl.style.display = 'block';
            }

            // ✅ CHECKED OUT
            else if (a.check_in && a.check_out) {
                todayStatusEl.innerHTML = 'Checked Out <i class="fas fa-sign-out-alt"></i>';
                todayStatusEl.style.color = '#FF9800';

                checkInEl.textContent = Helpers.formatTime(a.check_in);
                checkInEl.style.color = '#FF9800';

                checkOutEl.textContent = `Out: ${Helpers.formatTime(a.check_out)}`;
                checkOutEl.style.color = '#FF9800';
                checkOutEl.style.display = 'block';
            }

            // ✅ NO ATTENDANCE TODAY
            else {
                todayStatusEl.innerHTML = 'Not Checked In <i class="fas fa-clock"></i>';
                todayStatusEl.style.color = '#f44336';

                checkInEl.textContent = '--:--';
                checkOutEl.textContent = 'Out: --:--';
                checkOutEl.style.display = 'block';
            }
        } else {
            // No attendance record today
            todayStatusEl.innerHTML = 'Not Checked In <i class="fas fa-clock"></i>';
            todayStatusEl.style.color = '#f44336';

            checkInEl.textContent = '--:--';
            checkOutEl.textContent = 'Out: --:--';
            checkOutEl.style.display = 'block';
        }

        // Update last update time
        updateLastUpdateTime();
        
        console.log('Today status updated successfully');

    } catch (error) {
        console.error('Error loading today status:', error);
        Helpers.getElement('todayStatus').textContent = 'Error';
        Helpers.getElement('todayStatus').style.color = '#f44336';
    }
}


// =========== TODAY'S STATUS (FIXED VERSION) ===========
async function loadTodayStatus() {
    try {
        console.log('🔄 Loading today\'s status...');
        
        // Get current user info
        if (!API.user) {
            console.log('No user logged in');
            return;
        }
        
        console.log('Current user:', API.user);
        
        // Call API to get today's attendance
        const response = await API.getTodayAttendance();
        console.log('Today status API response:', response);
        
        // Get DOM elements
        const todayStatusEl = Helpers.getElement('todayStatus');
        const checkInEl = Helpers.getElement('checkInTime');
        
        // Create checkOut element if it doesn't exist
        let checkOutEl = Helpers.getElement('checkOutTime');
        if (!checkOutEl && checkInEl && checkInEl.parentNode) {
            checkOutEl = document.createElement('div');
            checkOutEl.id = 'checkOutTime';
            checkOutEl.className = 'checkout-time';
            checkOutEl.style.fontSize = '14px';
            checkOutEl.style.marginTop = '5px';
            checkOutEl.style.color = '#666';
            checkInEl.parentNode.appendChild(checkOutEl);
        }
        
        // Reset to default state
        if (todayStatusEl) {
            todayStatusEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            todayStatusEl.style.color = '#666';
        }
        
        if (checkInEl) {
            checkInEl.textContent = '--:--';
            checkInEl.style.color = '#666';
        }
        
        if (checkOutEl) {
            checkOutEl.textContent = 'Out: --:--';
            checkOutEl.style.color = '#666';
            checkOutEl.style.display = 'block';
        }
        
        // Process the API response
        if (response.success) {
            if (response.attendance) {
                const attendance = response.attendance;
                console.log('Found attendance record:', attendance);
                
                // Extract times
                const checkInTime = attendance.check_in ? 
                    Helpers.formatTime(attendance.check_in) : '--:--';
                const checkOutTime = attendance.check_out ? 
                    Helpers.formatTime(attendance.check_out) : '--:--';
                
                // Determine status
                if (attendance.check_in && !attendance.check_out) {
                    // ✅ Checked in, not checked out
                    todayStatusEl.innerHTML = '<i class="fas fa-check-circle"></i> Checked In';
                    todayStatusEl.style.color = '#4CAF50';
                    checkInEl.textContent = checkInTime;
                    checkInEl.style.color = '#4CAF50';
                    checkOutEl.textContent = 'Out: --:--';
                    checkOutEl.style.color = '#666';
                    
                    console.log('Status: Checked In at', checkInTime);
                    
                } else if (attendance.check_in && attendance.check_out) {
                    // ✅ Checked out
                    todayStatusEl.innerHTML = '<i class="fas fa-sign-out-alt"></i> Checked Out';
                    todayStatusEl.style.color = '#FF9800';
                    checkInEl.textContent = checkInTime;
                    checkInEl.style.color = '#FF9800';
                    checkOutEl.textContent = `Out: ${checkOutTime}`;
                    checkOutEl.style.color = '#FF9800';
                    
                    console.log('Status: Checked Out at', checkOutTime);
                    
                } else {
                    // ❌ Not checked in today
                    todayStatusEl.innerHTML = '<i class="fas fa-clock"></i> Not Checked In';
                    todayStatusEl.style.color = '#f44336';
                    checkInEl.textContent = '--:--';
                    checkOutEl.textContent = 'Out: --:--';
                    
                    console.log('Status: Not Checked In Today');
                }
            } else {
                // No attendance record today
                todayStatusEl.innerHTML = '<i class="fas fa-clock"></i> Not Checked In';
                todayStatusEl.style.color = '#f44336';
                checkInEl.textContent = '--:--';
                checkOutEl.textContent = 'Out: --:--';
                
                console.log('Status: No attendance record found');
            }
        } else {
            // API error
            todayStatusEl.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error';
            todayStatusEl.style.color = '#f44336';
            console.error('Today status API error:', response.message);
        }
        
        // Update timestamp
        updateLastUpdateTime();
        
    } catch (error) {
        console.error('❌ Error loading today status:', error);
        
        const todayStatusEl = Helpers.getElement('todayStatus');
        if (todayStatusEl) {
            todayStatusEl.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error';
            todayStatusEl.style.color = '#f44336';
        }
    }
}
*/

async function loadTodayStatus() {
    try {
        if (!API.user) return;

        const res = await API.getTodayAttendance();

        const todayStatus = Helpers.getElement('todayStatus');
        const checkIn = Helpers.getElement('checkInTime');
        let checkOut = Helpers.getElement('checkOutTime');

        // create checkout element if missing
        if (!checkOut && checkIn.parentNode) {
            checkOut = document.createElement('p');
            checkOut.id = 'checkOutTime';
            checkIn.parentNode.appendChild(checkOut);
        }

        // default
        todayStatus.textContent = 'Not Checked In';
        todayStatus.style.color = '#f44336';
        checkIn.textContent = '--:--';
        checkOut.textContent = 'Out: --:--';

        if (res.success && res.attendance) {
            const a = res.attendance;

            if (a.check_in && !a.check_out) {
                todayStatus.textContent = 'Checked In';
                todayStatus.style.color = '#4CAF50';
                checkIn.textContent = Helpers.formatTime(a.check_in);
            }

            if (a.check_in && a.check_out) {
                todayStatus.textContent = 'Checked Out';
                todayStatus.style.color = '#FF9800';
                checkIn.textContent = Helpers.formatTime(a.check_in);
                checkOut.textContent = `Out: ${Helpers.formatTime(a.check_out)}`;
            }
        }

        updateLastUpdateTime();

    } catch (e) {
        console.error('Today status error', e);
    }
}


// =========== MONTHLY STATISTICS ===========
async function loadMonthlyStats() {
    try {
        // Get current month range
        const now = new Date();
        const startOfMonth = Helpers.getStartOfMonth();
        const endOfMonth = Helpers.getEndOfMonth();
        
        // Get attendance for current month
        const response = await API.getAttendanceHistory(startOfMonth, endOfMonth);
        
        if (response.success && response.history) {
            const history = response.history;
            const currentDate = new Date();
            const currentDay = currentDate.getDate();
            const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
            
            // Count unique days with attendance
            const attendanceDates = new Set();
            history.forEach(record => {
                if (record.check_in) {
                    const date = new Date(record.check_in).toISOString().split('T')[0];
                    attendanceDates.add(date);
                }
            });
            
            const daysPresent = attendanceDates.size;
            const attendanceRate = Math.round((daysPresent / currentDay) * 100);
            
            // Update UI
            Helpers.getElement('monthDays').textContent = `${daysPresent}/${currentDay} days`;
            Helpers.getElement('attendanceRate').textContent = `${attendanceRate}%`;
            
            // Add progress bar for attendance rate
            updateAttendanceProgressBar(attendanceRate);
            
            // Calculate average work hours
            calculateAverageWorkHours(history);
            
        } else {
            // Default values if no data
            const currentDay = new Date().getDate();
            Helpers.getElement('monthDays').textContent = `0/${currentDay} days`;
            Helpers.getElement('attendanceRate').textContent = '0%';
        }
        
    } catch (error) {
        console.error('Error loading monthly stats:', error);
        Helpers.getElement('monthDays').textContent = 'Error';
        Helpers.getElement('attendanceRate').textContent = 'Error';
    }
}

// =========== ATTENDANCE PROGRESS BAR ===========
function updateAttendanceProgressBar(percentage) {
    let progressBar = Helpers.getElement('attendanceProgressBar');
    
    if (!progressBar) {
        // Create progress bar if it doesn't exist
        const attendanceRateElement = Helpers.getElement('attendanceRate');
        if (attendanceRateElement && attendanceRateElement.parentNode) {
            progressBar = document.createElement('div');
            progressBar.id = 'attendanceProgressBar';
            progressBar.style.width = '100%';
            progressBar.style.height = '8px';
            progressBar.style.backgroundColor = '#e0e0e0';
            progressBar.style.borderRadius = '4px';
            progressBar.style.marginTop = '10px';
            progressBar.style.overflow = 'hidden';
            
            const progressFill = document.createElement('div');
            progressFill.style.width = `${percentage}%`;
            progressFill.style.height = '100%';
            progressFill.style.backgroundColor = percentage >= 80 ? '#4CAF50' : 
                                               percentage >= 60 ? '#FF9800' : '#f44336';
            progressFill.style.transition = 'width 0.5s ease';
            
            progressBar.appendChild(progressFill);
            attendanceRateElement.parentNode.appendChild(progressBar);
        }
    } else {
        // Update existing progress bar
        const progressFill = progressBar.querySelector('div');
        if (progressFill) {
            progressFill.style.width = `${percentage}%`;
            progressFill.style.backgroundColor = percentage >= 80 ? '#4CAF50' : 
                                               percentage >= 60 ? '#FF9800' : '#f44336';
        }
    }
}

// =========== CALCULATE AVERAGE WORK HOURS ===========
function calculateAverageWorkHours(history) {
    let totalHours = 0;
    let daysWithCheckout = 0;
    
    history.forEach(record => {
        if (record.check_in && record.check_out) {
            const start = new Date(record.check_in);
            const end = new Date(record.check_out);
            const workHours = (end - start) / (1000 * 60 * 60); // Convert to hours
            totalHours += workHours;
            daysWithCheckout++;
        }
    });
    
    if (daysWithCheckout > 0) {
        const avgHours = totalHours / daysWithCheckout;
        
        // Add average hours display if not exists
        let avgHoursElement = Helpers.getElement('avgWorkHours');
        if (!avgHoursElement) {
            // Find a place to add it (maybe after attendance rate)
            const attendanceRateCard = Helpers.getElement('attendanceRate').closest('.stat-card');
            if (attendanceRateCard) {
                avgHoursElement = document.createElement('div');
                avgHoursElement.id = 'avgWorkHours';
                avgHoursElement.style.marginTop = '10px';
                avgHoursElement.style.fontSize = '14px';
                avgHoursElement.style.color = '#666';
                avgHoursElement.innerHTML = `<i class="fas fa-clock"></i> Avg: ${avgHours.toFixed(1)}h/day`;
                attendanceRateCard.appendChild(avgHoursElement);
            }
        } else {
            avgHoursElement.innerHTML = `<i class="fas fa-clock"></i> Avg: ${avgHours.toFixed(1)}h/day`;
        }
    }
}

// =========== GPS DISTANCE ===========
async function loadGPSDistance() {
    try {
        const location = await Helpers.getLocation();
        const distance = Helpers.calculateDistance(
            location.lat, 
            location.lng,
            13.1262, // Office lat
            80.2335 // Office lng
        );
        
        const distanceElement = Helpers.getElement('officeDistance');
        distanceElement.textContent = `${Math.round(distance)} meters`;
        
        // Color codingf
        if (distance > 100) {
            distanceElement.style.color = '#f44336'; // Red - too far
            distanceElement.innerHTML += ' <i class="fas fa-exclamation-triangle" title="Too far from office"></i>';
        } else if (distance > 50) {
            distanceElement.style.color = '#FF9800'; // Orange - borderline
        } else {
            distanceElement.style.color = '#4CAF50'; // Green - good
            distanceElement.innerHTML += ' <i class="fas fa-check-circle" title="Within office radius"></i>';
        }
        
    } catch (error) {
        console.log('GPS not available:', error.message);
        Helpers.getElement('officeDistance').textContent = 'GPS unavailable';
        Helpers.getElement('officeDistance').style.color = '#666';
        Helpers.getElement('officeDistance').innerHTML += ' <i class="fas fa-map-marker-slash" title="GPS disabled"></i>';
    }
}

/*
// =========== ATTENDANCE STREAK ===========
async function loadAttendanceStreak() {
    try {
        // Get last 30 days of attendance
        const endDate = new Date().toISOString().split('T')[0];
        const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        
        const response = await API.getAttendanceHistory(startDate, endDate);
        
        if (response.success && response.history) {
            // Sort by date and get unique dates
            const dates = new Set();
            response.history.forEach(record => {
                if (record.check_in) {
                    const date = new Date(record.check_in).toISOString().split('T')[0];
                    dates.add(date);
                }
            });
            
            // Calculate current streak
            const dateArray = Array.from(dates).sort().reverse();
            let streak = 0;
            const today = new Date().toISOString().split('T')[0];
            const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            
            // Check today
            if (dateArray.includes(today)) {
                streak++;
                // Check consecutive days
                let checkDate = new Date(today);
                for (let i = 1; i < 30; i++) {
                    checkDate.setDate(checkDate.getDate() - 1);
                    const checkDateStr = checkDate.toISOString().split('T')[0];
                    if (dateArray.includes(checkDateStr)) {
                        streak++;
                    } else {
                        break;
                    }
                }
            } else if (dateArray.includes(yesterday)) {
                // Started yesterday but not today yet
                streak = 0;
            }
            
            // Display streak
           // displayAttendanceStreak(streak);
        }
        
    } catch (error) {
        console.error('Error loading streak:', error);
    }
}

*/



// =========== SIMPLE PROFILE LOADING ===========
async function loadProfileData() {
    if (!API.user) return;
    
    // Update with current user data
    Helpers.getElement('profileName').textContent = API.user.name;
    Helpers.getElement('profileEmail').textContent = API.user.email;
    Helpers.getElement('profileEmployeeId').textContent = API.user.employee_id;
    
    Helpers.getElement('detailEmployeeId').textContent = API.user.employee_id;
    Helpers.getElement('detailFullName').textContent = API.user.name;
    Helpers.getElement('detailEmail').textContent = API.user.email;
    
    // Try to get fresh data
    try {
        const response = await API.getProfile();
        if (response.success && response.employee) {
            const emp = response.employee;
            
            // Dates
            Helpers.getElement('detailCreatedAt').textContent = 
                emp.created_at ? Helpers.formatDate(emp.created_at) : 'Unknown';
            
            Helpers.getElement('detailLastLogin').textContent = 
                emp.last_login ? Helpers.formatDateTime(emp.last_login) : 'Never';
            
            // Face status
            const faceStatus = Helpers.getElement('detailFaceRecognition');
            if (emp.has_face_encoding) {
                faceStatus.innerHTML = '<span style="background: #d4edda; color: #155724; padding: 5px 10px; border-radius: 15px; font-size: 12px;">✓ Registered</span>';
            } else {
                faceStatus.innerHTML = '<span style="background: #fff3cd; color: #856404; padding: 5px 10px; border-radius: 15px; font-size: 12px;">Not Registered</span>';
            }
        }
    } catch (error) {
        console.log('Profile details error:', error);
        // Use default values
        Helpers.getElement('detailCreatedAt').textContent = 'Unknown';
        Helpers.getElement('detailLastLogin').textContent = 'Never';
        Helpers.getElement('detailFaceRecognition').innerHTML = 
            '<span style="color: #666;">Check with admin</span>';
    }
}

// =========== SIMPLE PASSWORD CHANGE ===========
function openChangePasswordModal() {
    const modal = Helpers.getElement('changePasswordModal');
    modal.style.display = 'flex';
    Helpers.getElement('currentPassword').focus();
}

function closePasswordModal() {
    Helpers.getElement('changePasswordModal').style.display = 'none';
    Helpers.getElement('changePasswordForm').reset();
}

async function handlePasswordChange(e) {
    e.preventDefault();
    
    const currentPass = Helpers.getElement('currentPassword').value;
    const newPass = Helpers.getElement('newPassword').value;
    const confirmPass = Helpers.getElement('confirmPassword').value;
    const submitBtn = Helpers.getElement('submitPasswordBtn');
    
    // Validation
    if (!currentPass || !newPass || !confirmPass) {
        alert('Please fill all fields');
        return;
    }
    
    if (newPass.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    if (newPass !== confirmPass) {
        alert('New passwords do not match');
        return;
    }
    
    if (newPass === currentPass) {
        alert('New password must be different from current password');
        return;
    }
    
    // Show loading
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing...';
    submitBtn.disabled = true;
    
    try {
        // CALL REAL BACKEND API
        const response = await API.changePassword(currentPass, newPass);
        
        if (response.success) {
            // SUCCESS
            alert('✅ ' + response.message);
            closePasswordModal();
            
            // Logout user after 1 second
            setTimeout(() => {
                API.logout().then(() => {
                    window.location.href = 'index.html';
                });
            }, 1000);
            
        } else {
            // FAILED
            alert('❌ ' + (response.message || 'Password change failed'));
        }
        
    } catch (error) {
        console.error('Password change error:', error);
        alert('❌ Network error. Please check backend server.');
    } finally {
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}


// =========== RESET HISTORY FILTER ===========
function resetHistoryFilter() {
    const startDateInput = Helpers.getElement('startDate');
    const endDateInput = Helpers.getElement('endDate');
    
    if (startDateInput) startDateInput.value = '';
    if (endDateInput) endDateInput.value = '';
    
    loadAttendanceHistory();
}

// =========== ATTENDANCE HANDLERS ===========
async function handleLocationCheck() {
    console.log('📍 Checking REAL location...');
    
    const locationStatus = Helpers.getElement('locationStatus');
    const stepLocation = Helpers.getElement('stepLocation');
    const checkLocationBtn = this;
    
    try {
        Helpers.setLoading(checkLocationBtn, true);
        locationStatus.textContent = 'Getting location...';
        locationStatus.className = 'step-status';
        
        // Get REAL GPS location
        const location = await Helpers.getLocation();
        console.log('📍 Real location obtained:', location);
        
        // Show location info
        locationStatus.innerHTML = 
            `📍 Location obtained!<br>
             Lat: ${location.lat.toFixed(6)}<br>
             Lng: ${location.lng.toFixed(6)}<br>
             Accuracy: ${Math.round(location.accuracy)} meters`;
        
        // Simulate distance check (backend will do real check)
        // For now, assume it's valid if we got coordinates
        await new Promise(resolve => setTimeout(resolve, 500));
        
        locationStatus.innerHTML += '<br>✅ Ready for verification';
        locationStatus.className = 'step-status completed';
        stepLocation.classList.add('completed');
        
        // Enable face check button
        Helpers.getElement('checkFaceBtn').disabled = false;
        
    } catch (error) {
        console.error('Location error:', error);
        locationStatus.textContent = `❌ ${error.message}`;
        locationStatus.className = 'step-status failed';
        
        // Offer simulated location for testing
        const useSimulated = confirm(
            `GPS Error: ${error.message}\n\n` +
            `Use simulated location for testing?`
        );
        
        if (useSimulated) {
            locationStatus.textContent = '📍 Using simulated location (testing)';
            locationStatus.className = 'step-status completed';
            stepLocation.classList.add('completed');
            Helpers.getElement('checkFaceBtn').disabled = false;
        }
    } finally {
        Helpers.setLoading(checkLocationBtn, false);
        checkAttendanceStatus();
    }
}

/*

async function handleFaceCheck() {
    console.log('📸 Checking face with REAL verification...');
    
    const faceStatus = Helpers.getElement('faceStatus');
    const stepFace = Helpers.getElement('stepFace');
    const checkFaceBtn = this;
    
    try {
        Helpers.setLoading(checkFaceBtn, true);
        faceStatus.textContent = 'Starting camera...';
        faceStatus.className = 'step-status';
        
        // 1. Load face recognition models
        if (!FaceRecognition.modelsLoaded) {
            await FaceRecognition.loadModels();
        }
        
        /*
        // 2. Start camera if not already started
        if (!FaceRecognition.videoElement || !FaceRecognition.videoElement.srcObject) {
            // Create a temporary video element for face capture
            const tempVideo = document.createElement('video');
            tempVideo.id = 'tempFaceVideo';
            tempVideo.style.display = 'none';
            document.body.appendChild(tempVideo);
            
            await FaceRecognition.startCamera('tempFaceVideo');
        }
        
        faceStatus.textContent = 'Capturing your face...';
        
       // 2. Show camera container and start camera

const cameraContainer = Helpers.getElement('faceCameraContainer');
const videoElement = Helpers.getElement('faceVerificationVideo');

if (cameraContainer) {
    cameraContainer.style.display = 'block';
}

// Start camera on visible video element
await FaceRecognition.startCamera('faceVerificationVideo');

// Wait a moment for camera to focus
faceStatus.textContent = 'Looking for face...';
await new Promise(resolve => setTimeout(resolve, 1000));


        
        // 3. Capture current face
        const captureResult = await FaceRecognition.captureFace();
        
        if (!captureResult.success) {
            throw new Error(captureResult.message || 'Failed to capture face');
        }
        
        faceStatus.textContent = 'Verifying with database...';
        
        // 4. Send to backend for verification
        const verifyResult = await API.verifyFace(
            API.user.employee_id,  // Current logged in employee
            captureResult.descriptor  // Captured face data
        );
        
        if (verifyResult.success && verifyResult.isMatch) {
            // SUCCESS: Face matches!
            faceStatus.innerHTML = 
                `✅ Verified!<br>
                 Confidence: ${verifyResult.confidence.toFixed(1)}%<br>
                 ${verifyResult.message}`;
            faceStatus.className = 'step-status completed';
            stepFace.classList.add('completed');
            
            console.log('✅ Face verification successful!', verifyResult);
        } else {
            // FAILED: Face doesn't match
            const errorMsg = verifyResult.message || 'Face verification failed';
            faceStatus.innerHTML = 
                `❌ ${errorMsg}<br>
                 Confidence: ${verifyResult.confidence?.toFixed(1) || 0}%`;
            faceStatus.className = 'step-status failed';
            
            // Show more details in console for debugging
            console.log('Face verification failed:', verifyResult);
            
            // Ask user to retry
            setTimeout(() => {
                if (confirm('Face verification failed. Do you want to try again?')) {
                    faceStatus.textContent = 'Try again - look at camera';
                    faceStatus.className = 'step-status';
                    Helpers.setLoading(checkFaceBtn, false);
                }
            }, 1000);
            
            return; // Don't proceed
        }
        
    } catch (error) {
        console.error('Face check error:', error);
        faceStatus.textContent = `❌ Face verification failed: ${error.message}`;
        faceStatus.className = 'step-status failed';
    }
    finally {
        Helpers.setLoading(checkFaceBtn, false);
        checkAttendanceStatus();
        
        // Hide camera container
        const cameraContainer = Helpers.getElement('faceCameraContainer');
        if (cameraContainer) {
            cameraContainer.style.display = 'none';
        }
        
        // Stop camera
        FaceRecognition.stopCamera();
    }
}

*/

async function handleFaceCheck() {
    console.log('📸 Checking face with REAL verification...');
    
    const faceStatus = Helpers.getElement('faceStatus');
    const stepFace = Helpers.getElement('stepFace');
    const checkFaceBtn = Helpers.getElement('checkFaceBtn');

    try {
        Helpers.setLoading(checkFaceBtn, true);
        faceStatus.textContent = 'Starting camera...';
        faceStatus.className = 'step-status';

        // Reset previous result
        faceVerificationResult.verified = false;
        faceVerificationResult.confidence = 0;

        // 1. Load models
        if (!FaceRecognition.modelsLoaded) {
            await FaceRecognition.loadModels();
        }

        // 2. Show camera
        const cameraContainer = Helpers.getElement('faceCameraContainer');
        if (cameraContainer) cameraContainer.style.display = 'block';

        await FaceRecognition.startCamera('faceVerificationVideo');

        faceStatus.textContent = 'Looking at camera...';
        await new Promise(r => setTimeout(r, 1200));

        // 3. Capture face
        const captureResult = await FaceRecognition.captureFace();
        if (!captureResult.success) {
            throw new Error(captureResult.message);
        }

        faceStatus.textContent = 'Verifying face...';

        // 4. Backend verification
        const verifyResult = await API.verifyFace(
            API.user.employee_id,
            captureResult.descriptor
        );

        // 5. STRICT THRESHOLD CHECK
        if (
            verifyResult.success &&
            verifyResult.isMatch &&
            verifyResult.confidence >= 70
        ) {
            faceVerificationResult.verified = true;
            faceVerificationResult.confidence = verifyResult.confidence;

            faceStatus.innerHTML = `
                ✅ Face Verified<br>
                Confidence: ${verifyResult.confidence.toFixed(1)}%
            `;
            faceStatus.className = 'step-status completed';
            stepFace.classList.add('completed');

        } else {
            faceVerificationResult.verified = false;
            faceVerificationResult.confidence = verifyResult.confidence || 0;

            faceStatus.innerHTML = `
                ❌ Face NOT verified<br>
                Confidence: ${verifyResult.confidence?.toFixed(1) || 0}%<br>
                <small>Minimum required: 70%</small>
            `;
            faceStatus.className = 'step-status failed';
            return;
        }

    } catch (error) {
        console.error('Face check error:', error);
        faceStatus.textContent = `❌ ${error.message}`;
        faceStatus.className = 'step-status failed';

    } finally {
        Helpers.setLoading(checkFaceBtn, false);

        const cameraContainer = Helpers.getElement('faceCameraContainer');
        if (cameraContainer) cameraContainer.style.display = 'none';

        FaceRecognition.stopCamera();
        checkAttendanceStatus();
    }
}


function checkAttendanceStatus() {
    const locationCompleted = Helpers.getElement('locationStatus').classList.contains('completed');
    const faceCompleted = Helpers.getElement('faceStatus').classList.contains('completed');
    const submitBtn = Helpers.getElement('submitAttendanceBtn');
    
    if (locationCompleted && faceCompleted) {
        submitBtn.disabled = false;
        Helpers.getElement('stepSubmit').classList.add('completed');
    } else {
        submitBtn.disabled = true;
    }
}


/*
async function handleSubmitAttendance() {
    console.log('✅ Submitting attendance with REAL GPS...');
    
    const submitBtn = Helpers.getElement('submitAttendanceBtn');
    
    try {
        Helpers.setLoading(submitBtn, true);
        
        // 1. GET REAL GPS LOCATION
        let gps_lat, gps_lng, gps_accuracy;
        try {
            const location = await Helpers.getLocation();
            gps_lat = location.lat;
            gps_lng = location.lng;
            gps_accuracy = location.accuracy;
            
            console.log(`📍 GPS: ${gps_lat}, ${gps_lng} (Accuracy: ${gps_accuracy}m)`);
            
            // Show GPS info to user
            Helpers.getElement('locationStatus').innerHTML = 
                `📍 Location captured<br>
                 Accuracy: ${Math.round(gps_accuracy)} meters`;
            
        } catch (error) {
            console.error('GPS failed:', error);
            
            // Ask user if they want to retry or use simulated
            const useSimulated = confirm(
                `GPS Error: ${error.message}\n\n` +
                `Do you want to use simulated location for testing?\n` +
                `(Click Cancel to retry GPS)`
            );
            
            if (useSimulated) {
                gps_lat = 13.1262;  // Office latitude, // Office lat (will get from API later)
            
                gps_lng = 80.2335;  // Office longitude
                gps_accuracy = 10;
                
                Helpers.getElement('locationStatus').innerHTML = 
                    '📍 Using simulated location (testing mode)';
            } else {
                throw error; // Let user retry
            }
        }
        
        // 2. PREPARE ATTENDANCE DATA
        const attendanceData = {
            gps_lat: gps_lat,
            gps_lng: gps_lng,
            face_verified: true  // Will update with real face check later
        };
        
        console.log('📤 Sending attendance data:', attendanceData);
        
        // 3. CALL REAL API
        const response = await API.markAttendance(attendanceData);
        
        // 4. HANDLE RESPONSE
        if (response.success) {
            // Show success with distance info
            const distance = response.location_details?.distance;
            const message = distance 
                ? `✅ Attendance marked successfully!\nYou are ${Math.round(distance)} meters from office`
                : '✅ Attendance marked successfully!';
            
            alert(message);
            
            // Reset attendance page
            resetAttendancePage();
            
            // Go back to dashboard
            navigateToPage('home');
            
            // Refresh dashboard data
            loadDashboardData();
            
        } else {
            // Show GPS error details
            const errorMsg = response.location_details?.message 
                ? `❌ ${response.message}\n${response.location_details.message}`
                : `❌ ${response.message}`;
            
            throw new Error(errorMsg);
        }
        
    } catch (error) {
        console.error('Attendance submission error:', error);
        
        // Show user-friendly error
        let userMessage = error.message;
        if (error.message.includes('Too far from office')) {
            userMessage = `🚫 Too far from office!\n\n` +
                         `Please come within 100 meters of the office to mark attendance.\n` +
                         `Current distance: ${error.message.match(/\d+/)[0]} meters`;
        }
        
        alert(userMessage);
        
        // Reset only location step (allow retry)
        Helpers.getElement('locationStatus').textContent = 'GPS Failed - Try Again';
        Helpers.getElement('locationStatus').className = 'step-status failed';
        Helpers.getElement('checkLocationBtn').disabled = false;
        
    } finally {
        Helpers.setLoading(submitBtn, false);
    }
}
*/

async function handleSubmitAttendance() {
    console.log('✅ Submitting attendance...');
    
    const submitBtn = Helpers.getElement('submitAttendanceBtn');

    try {
        // 🔐 HARD BLOCK IF FACE FAILED
        if (!faceVerificationResult.verified) {
            alert('❌ Face not verified.\nAttendance blocked.');
            return;
        }

        Helpers.setLoading(submitBtn, true);

        // 1. GET GPS
        const location = await Helpers.getLocation();

        // 2. SEND REAL VERIFIED DATA
        const attendanceData = {
            gps_lat: location.lat,
            gps_lng: location.lng,
            face_verified: true,
            face_confidence: faceVerificationResult.confidence
        };

        const response = await API.markAttendance(attendanceData);

        if (!response.success) {
            throw new Error(response.message);
        }

        alert(
            `✅ Attendance marked\nFace confidence: ${faceVerificationResult.confidence.toFixed(1)}%`
        );

        // Reset state
        faceVerificationResult.verified = false;
        faceVerificationResult.confidence = 0;

        resetAttendancePage();
        navigateToPage('home');
        loadDashboardData();

    } catch (error) {
        console.error('Attendance error:', error);
        alert(`❌ ${error.message}`);
    } finally {
        Helpers.setLoading(submitBtn, false);
    }
}


function resetAttendancePage() {
    // Reset location step
    Helpers.getElement('locationStatus').textContent = 'Not checked';
    Helpers.getElement('locationStatus').className = 'step-status';
    Helpers.getElement('stepLocation').classList.remove('completed');
    Helpers.getElement('checkLocationBtn').disabled = false;
    
    // Reset face step
    Helpers.getElement('faceStatus').textContent = 'Not verified';
    Helpers.getElement('faceStatus').className = 'step-status';
    Helpers.getElement('stepFace').classList.remove('completed');
    Helpers.getElement('checkFaceBtn').disabled = true;
    
    // Reset submit step
    Helpers.getElement('stepSubmit').classList.remove('completed');
    Helpers.getElement('submitAttendanceBtn').disabled = true;
}

/*
async function handleQuickCheckOut() {
    console.log('🚪 Quick check-out...');

    const button = Helpers.getElement('quickCheckOut');

    try {
        Helpers.setLoading(button, true);

        const response = await API.checkOut();

        if (response.success && response.attendance) {
            alert(`✅ Checked out at ${Helpers.formatTime(response.attendance.check_out)}`);

            // 🔥 ALWAYS reload from backend
            await loadTodayStatus();
            await loadRecentActivity();

        } else {
            alert('ℹ️ ' + (response.message || 'Already checked out'));
        }

    } catch (error) {
        console.error('Quick check-out error:', error);
        alert('❌ Check-out failed: ' + error.message);
    } finally {
        Helpers.setLoading(button, false);
    }
}
*/
async function handleQuickCheckOut() {
    console.log('🚪 Quick check-out...');

    const button = Helpers.getElement('quickCheckOut');

    try {
        Helpers.setLoading(button, true);

        const response = await API.checkOut();
        console.log('Check-out response:', response);

        if (response.success) {
            let message = response.message || 'Checked out successfully';
            
            if (response.attendance && response.attendance.check_out) {
                const checkOutTime = Helpers.formatTime(response.attendance.check_out);
                message = `✅ Checked out at ${checkOutTime}`;
            }
            
            alert(message);

            // 🔥 Force reload dashboard data
            await Promise.all([
                loadTodayStatus(),
                loadMonthlyStats(),
                loadRecentActivity()
            ]);
            
            console.log('Dashboard refreshed after check-out');

        } else {
            alert('ℹ️ ' + (response.message || 'Check-out failed'));
        }

    } catch (error) {
        console.error('Quick check-out error:', error);
        alert('❌ Check-out failed: ' + error.message);
    } finally {
        Helpers.setLoading(button, false);
    }
}


function clearCheckInOutUI() {
    const checkInTime = Helpers.getElement('checkInTime');
    if (!checkInTime) return;

    checkInTime.textContent = '--:--';
    checkInTime.style.color = '#666';

    const parent = checkInTime.parentNode;
    parent.querySelectorAll('div').forEach(div => div.remove());
}


// =========== PRO PAGE HANDLERS ===========
async function handleSetupFaceRecognition() {
    alert('📸 Face recognition setup will be implemented in Phase 5');
    // Will be implemented when we add face-api.js
}

async function handleChangePassword() {
    alert('🔑 Password change feature will be implemented later');
    // TODO: Implement password change modal
}

// =========== UTILITY FUNCTIONS ===========
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
        <button class="close-notification">&times;</button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
    
    // Close button
    notification.querySelector('.close-notification').addEventListener('click', () => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    });
}

// =========== GLOBAL ERROR HANDLER ===========
window.addEventListener('error', function(event) {
    console.error('Global error:', event.error);
    showNotification('An error occurred. Check console for details.', 'error');
});

// Make functions available globally for debugging
window.App = {
    API,
    Helpers,
    showDashboard,
    showLoginScreen,
    navigateToPage,
    loadUserProfile
};

// =========== MOBILE SPECIFIC FUNCTIONALITY ===========
function setupMobileFeatures() {
    // Detect if mobile
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
        console.log('📱 Mobile device detected');
        
        // Add touch feedback for buttons
        document.querySelectorAll('button').forEach(button => {
            button.addEventListener('touchstart', function() {
                this.style.opacity = '0.7';
            });
            
            button.addEventListener('touchend', function() {
                this.style.opacity = '1';
            });
        });
        
        // Prevent zoom on input focus for iOS
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('focus', function() {
                if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
                    this.style.fontSize = '16px';
                }
            });
        });
        
        // Handle back button on Android
        if (window.history && window.history.pushState) {
            window.addEventListener('popstate', function() {
                if (API.isLoggedIn()) {
                    // If logged in and back button pressed, show confirmation
                    if (confirm('Are you sure you want to logout?')) {
                        handleLogout();
                    } else {
                        // Push state again to prevent leaving
                        history.pushState(null, null, window.location.href);
                    }
                }
            });
        }
        
        // Add vibration feedback for important actions (optional)
        if (navigator.vibrate) {
            const importantButtons = ['#quickCheckIn', '#checkLocationBtn', '#submitAttendanceBtn', '#logoutBtn'];
            importantButtons.forEach(selector => {
                const btn = document.querySelector(selector);
                if (btn) {
                    btn.addEventListener('click', () => {
                        navigator.vibrate(50); // 50ms vibration
                    });
                }
            });
        }
    }
}

// Call this function in initApp()
async function initApp() {
    console.log('🔧 Initializing application...');
    
    // Test backend connection on startup
    await testBackendConnection();
    
    // Setup event listeners
    setupEventListeners();
    
    // Setup mobile features
    setupMobileFeatures(); // Add this line
    
    // Check if user is already logged in
    checkExistingLogin();
    
    // Show current version
    console.log('🏁 Application initialized successfully');
}

console.log('🎉 script.js loaded successfully!');

// Add this function in script.js to test face recognition
async function testFaceRecognition() {
    console.log('🧪 Testing face recognition...');
    
    try {
        // Load models
        await FaceRecognition.loadModels();
        console.log('✅ Models loaded');
        
        // Start camera
        await FaceRecognition.startCamera('testVideo'); // You'll need a video element
        
        // Capture face
        const result = await FaceRecognition.captureFace();
        console.log('Face capture result:', result);
        
        return result;
        
    } catch (error) {
        console.error('Face test failed:', error);
        return { success: false, error: error.message };
    }
}



/*
//check
console.log('👑 Admin dashboard - Starting initialization...');

// Check if admin is logged in
if (!localStorage.getItem('isAdmin')) {
    console.log('⚠️ Not logged in as admin, redirecting...');
    window.location.href = 'admin-login.html';
} else {
    console.log('✅ Admin logged in:', localStorage.getItem('adminUsername'));
}

// State variables
let currentEmployee = null;
let capturedFaceData = null;
let employeeSaved = false;

// DOM Elements
const adminUsername = localStorage.getItem('adminUsername') || 'Administrator';
console.log('Setting admin username:', adminUsername);

// Check if elements exist
console.log('Checking elements...');
console.log('navUser element:', document.getElementById('navUser'));
console.log('adminUsername element:', document.getElementById('adminUsername'));
console.log('sidebar-nav element:', document.querySelector('.sidebar-nav'));
console.log('nav items found:', document.querySelectorAll('.sidebar-nav .nav-item').length);

// Set username
const usernameElement = document.getElementById('adminUsername');
if (usernameElement) {
    usernameElement.textContent = adminUsername;
}



// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('👑 Admin dashboard DOM loaded');
    
    setupEventListeners();
    loadDashboardStats();
    loadEmployees();
    
    // Auto-generate password
    generatePassword();
});
*/


// =========== EXPORT ATTENDANCE HISTORY ===========
function exportAttendanceHistory() {
    console.log('📤 Exporting attendance history...');
    
    // Get current history data
    const tableBody = Helpers.getElement('attendanceTableBody');
    if (!tableBody || tableBody.rows.length === 0) {
        alert('No attendance data to export');
        return;
    }
    
    // Get all rows from table
    const rows = tableBody.querySelectorAll('tr');
    if (rows.length === 0) {
        alert('No attendance records found');
        return;
    }
    
    // Prepare CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Add headers
    const headers = [
        'Date', 
        'Day', 
        'Employee ID', 
        'Employee Name', 
        'Check In', 
        'Check Out', 
        'Work Hours', 
        'GPS Latitude', 
        'GPS Longitude',
        'Face Verified',
        'Location Verified',
        'Status'
    ];
    csvContent += headers.join(',') + "\n";
    
    // Get raw history data from API
    API.getAttendanceHistory().then(response => {
        if (response.success && response.history && response.history.length > 0) {
            response.history.forEach(record => {
                // Format date
                const date = new Date(record.check_in);
                const dateString = Helpers.formatDate(record.check_in);
                const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
                const checkInTime = Helpers.formatTime(record.check_in);
                const checkOutTime = record.check_out ? Helpers.formatTime(record.check_out) : '--:--';
                
                // Calculate work hours
                let workHours = '--';
                if (record.check_in && record.check_out) {
                    const start = new Date(record.check_in);
                    const end = new Date(record.check_out);
                    const diffMs = end - start;
                    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
                    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                    workHours = `${diffHours}h ${diffMinutes}m`;
                }
                
                // Status
                let status = 'Present';
                if (!record.check_out) status = 'Active';
                
                // GPS data (handle string to number conversion)
                const gpsLat = record.gps_lat ? parseFloat(record.gps_lat) : '';
                const gpsLng = record.gps_lng ? parseFloat(record.gps_lng) : '';
                
                // Prepare row data
                const rowData = [
                    `"${dateString}"`,
                    `"${dayName}"`,
                    `"${record.emp_code || ''}"`,
                    `"${record.full_name || ''}"`,
                    `"${checkInTime}"`,
                    `"${checkOutTime}"`,
                    `"${workHours}"`,
                    gpsLat || '',
                    gpsLng || '',
                    record.face_verified ? 'Yes' : 'No',
                    record.location_verified ? 'Yes' : 'No',
                    `"${status}"`
                ];
                
                csvContent += rowData.join(',') + "\n";
            });
            
            // Create download link
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            
            // Generate filename with current date
            const now = new Date();
            const filename = `attendance_history_${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}.csv`;
            link.setAttribute("download", filename);
            
            // Trigger download
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            console.log('✅ Export completed:', filename);
            
        } else {
            alert('No attendance data available for export');
        }
    }).catch(error => {
        console.error('Export error:', error);
        alert('Failed to export attendance data');
    });
}


// =========== LOAD RECENT ACTIVITY ===========
async function loadRecentActivity() {
    try {
        // Get last 5 attendance records
        const response = await API.getAttendanceHistory();
        
        if (response.success && response.history && response.history.length > 0) {
            const recentList = Helpers.getElement('recentActivityList');
            const recent = response.history.slice(0, 5); // Get first 5
            
            let html = '<div style="display: flex; flex-direction: column; gap: 10px;">';
            
            recent.forEach(record => {
                const date = new Date(record.check_in);
                const time = Helpers.formatTime(record.check_in);
                const status = record.check_out ? 'Checked Out' : 'Checked In';
                const statusColor = record.check_out ? '#FF9800' : '#4CAF50';
                const icon = record.check_out ? 'fa-sign-out-alt' : 'fa-sign-in-alt';
                
                html += `
                    <div style="display: flex; align-items: center; padding: 10px; background: #f9f9f9; border-radius: 5px;">
                        <div style="background: ${statusColor}; color: white; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px;">
                            <i class="fas ${icon}"></i>
                        </div>
                        <div style="flex: 1;">
                            <div style="font-weight: bold;">${status}</div>
                            <div style="font-size: 14px; color: #666;">
                                ${Helpers.formatDateTime(record.check_in)}
                                ${record.check_out ? ` to ${Helpers.formatTime(record.check_out)}` : ''}
                            </div>
                        </div>
                        <div style="font-size: 12px; color: #999;">
                            ${record.location_verified ? '<i class="fas fa-map-marker-alt" title="Location verified"></i>' : ''}
                            ${record.face_verified ? '<i class="fas fa-user-check" title="Face verified"></i>' : ''}
                        </div>
                    </div>
                `;
            });
            
            html += '</div>';
            recentList.innerHTML = html;
            
        } else {
            Helpers.getElement('recentActivityList').innerHTML = 
                '<p style="color: #666; text-align: center;">No recent activity found</p>';
        }
        
    } catch (error) {
        console.error('Error loading recent activity:', error);
        Helpers.getElement('recentActivityList').innerHTML = 
            '<p style="color: #f44336; text-align: center;">Error loading activity</p>';
    }
}