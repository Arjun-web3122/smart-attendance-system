// =========== IMPORT DEPENDENCIES ===========
import pool from '../config/db.js';

// =========== ATTENDANCE MODEL ===========
class Attendance {

    // =========== GET TODAY DATE (LOCAL) ===========
    static getTodayDate(date = new Date()) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // =========== CHECK IN ===========
    static async checkIn(attendanceData) {
        const {
            employee_id,
            gps_lat,
            gps_lng,
            face_verified = false,
            location_verified = false
        } = attendanceData;

        try {
            const today = this.getTodayDate();

            // ❌ Prevent multiple check-ins in same day
            const existingQuery = `
                SELECT *
                FROM attendance
                WHERE employee_id = $1
                  AND DATE(check_in) = $2
                  AND check_out IS NULL
            `;

            const existing = await pool.query(existingQuery, [employee_id, today]);

            if (existing.rows.length > 0) {
                throw new Error('Already checked in today');
            }

            // ✅ Insert check-in
            const insertQuery = `
                INSERT INTO attendance
                (employee_id, gps_lat, gps_lng, face_verified, location_verified, check_in)
                VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
                RETURNING *
            `;

            const values = [
                employee_id,
                gps_lat,
                gps_lng,
                face_verified,
                location_verified
            ];

            const result = await pool.query(insertQuery, values);
            return result.rows[0];

        } catch (error) {
            console.error('Check-in error:', error);
            throw error;
        }
    }

    // =========== CHECK OUT ===========
    static async checkOut(employeeId) {
        try {
            const today = this.getTodayDate();

            const findQuery = `
                SELECT *
                FROM attendance
                WHERE employee_id = $1
                  AND DATE(check_in) = $2
                  AND check_out IS NULL
                ORDER BY check_in DESC
                LIMIT 1
            `;

            const findResult = await pool.query(findQuery, [employeeId, today]);

            if (findResult.rows.length === 0) {
                throw new Error('No active check-in found');
            }

            const attendance = findResult.rows[0];

            const updateQuery = `
                UPDATE attendance
                SET check_out = CURRENT_TIMESTAMP
                WHERE id = $1
                RETURNING *
            `;

            const updateResult = await pool.query(updateQuery, [attendance.id]);
            return updateResult.rows[0];

        } catch (error) {
            console.error('Check-out error:', error);
            throw error;
        }
    }

    // =========== FIND TODAY ATTENDANCE ===========
    static async findTodayAttendance(employee_id) {
        const query = `
            SELECT *
            FROM attendance
            WHERE employee_id = $1
              AND DATE(check_in) = CURRENT_DATE
            ORDER BY check_in DESC
            LIMIT 1
        `;

        const result = await pool.query(query, [employee_id]);
        return result.rows[0] || null;
    }

    // =========== ATTENDANCE HISTORY ===========
    static async getEmployeeHistory(employeeId, startDate = null, endDate = null) {
        let query = `
            SELECT *
            FROM attendance
            WHERE employee_id = $1
        `;

        const values = [employeeId];
        let count = 1;

        if (startDate) {
            count++;
            query += ` AND DATE(check_in) >= $${count}`;
            values.push(startDate);
        }

        if (endDate) {
            count++;
            query += ` AND DATE(check_in) <= $${count}`;
            values.push(endDate);
        }

        query += ` ORDER BY check_in DESC`;

        const result = await pool.query(query, values);
        return result.rows;
    }
}

export default Attendance;


/*
// =========== IMPORT DEPENDENCIES ===========
import pool from '../config/db.js';

// =========== ATTENDANCE CLASS ===========
class Attendance {

    /*
    // =========== CHECK IN ===========
    static async checkIn(attendanceData) {
        const {
            employee_id,
            gps_lat,
            gps_lng,
            face_verified = false,
            location_verified = false
        } = attendanceData;
        
        try {
            // Check if already checked in today (and not checked out)
            const today = new Date().toISOString().split('T')[0];
            const existing = await this.findTodayAttendance(employee_id, today);
            
            if (existing && !existing.check_out) {
                throw new Error('Already checked in today');
            }
            
            const query = `
                INSERT INTO attendance 
                (employee_id, gps_lat, gps_lng, face_verified, location_verified, check_in)
                VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
                RETURNING *
            `;
            
            const values = [employee_id, gps_lat, gps_lng, face_verified, location_verified];
            const result = await pool.query(query, values);
            
            console.log(`✅ Check-in recorded for employee ID: ${employee_id}`);
            return result.rows[0];
            
        } catch (error) {
            console.error('Error during check-in:', error);
            throw error;
        }
    }
  
    // =========== CHECK OUT ===========
    static async checkOut(employeeId) {
        try {
            // Find today's check-in that hasn't been checked out
            const today = new Date().toISOString().split('T')[0];
            const query = `
                UPDATE attendance 
                SET check_out = CURRENT_TIMESTAMP 
                WHERE employee_id = $1 
                AND DATE(check_in) = $2 
                AND check_out IS NULL
                RETURNING *
            `;
            
            const result = await pool.query(query, [employeeId, today]);
            
            if (result.rows.length === 0) {
                throw new Error('No active check-in found for today');
            }
            
            console.log(`✅ Check-out recorded for employee ID: ${employeeId}`);
            return result.rows[0];
            
        } catch (error) {
            console.error('Error during check-out:', error);
            throw error;
        }
    }

  

    // =========== CHECK OUT ===========
static async checkOut(employeeId) {
    try {
        // Find today's check-in that hasn't been checked out
        const today = new Date().toISOString().split('T')[0];
        const query = `
            UPDATE attendance 
            SET check_out = CURRENT_TIMESTAMP 
            WHERE employee_id = $1 
            AND DATE(check_in) = $2 
            AND check_out IS NULL
            RETURNING *
        `;
        
        const result = await pool.query(query, [employeeId, today]);
        
        if (result.rows.length === 0) {
            throw new Error('No active check-in found for today');
        }
        
        console.log(`✅ Check-out recorded for employee ID: ${employeeId}`);
        return result.rows[0];
        
    } catch (error) {
        console.error('Error during check-out:', error);
        throw error;
    }
}
      */
/*
// =========== CHECK IN ===========
static async checkIn(attendanceData) {
    const {
        employee_id,
        gps_lat,
        gps_lng,
        face_verified = false,
        location_verified = false
    } = attendanceData;
    
    try {
        const today = new Date().toISOString().split('T')[0];
        
        // 🔥 FIX: Check if already checked in TODAY and NOT checked out
        const existingQuery = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in) = $2 
            AND check_out IS NULL
        `;
        
        const existingResult = await pool.query(existingQuery, [employee_id, today]);
        
        if (existingResult.rows.length > 0) {
            // Already checked in today and hasn't checked out
            const existing = existingResult.rows[0];
            throw new Error(`Already checked in at ${new Date(existing.check_in).toLocaleTimeString()}. Check out first.`);
        }
        
        // Also check if checked in and checked out today (prevent re-check-in)
        const completedQuery = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in) = $2 
            AND check_out IS NOT NULL
        `;
        
        const completedResult = await pool.query(completedQuery, [employee_id, today]);
        
        if (completedResult.rows.length > 0) {
            throw new Error('Already checked in and out for today');
        }
        
        // Insert new check-in
        const insertQuery = `
            INSERT INTO attendance 
            (employee_id, gps_lat, gps_lng, face_verified, location_verified, check_in)
            VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
            RETURNING *
        `;
        
        const values = [employee_id, gps_lat, gps_lng, face_verified, location_verified];
        const result = await pool.query(insertQuery, values);
        
        console.log(`✅ Check-in recorded for employee ID: ${employee_id} at ${result.rows[0].check_in}`);
        return result.rows[0];
        
    } catch (error) {
        console.error('Error during check-in:', error);
        throw error;
    }
}

// =========== CHECK OUT ===========
static async checkOut(employeeId) {
    try {
        const today = new Date().toISOString().split('T')[0];
        
        // 🔥 FIX: Better check for active check-in
        console.log(`Checking for active check-in for employee: ${employeeId}, date: ${today}`);
        
        // First, check if there's any check-in today
        const checkQuery = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in) = $2
            ORDER BY check_in DESC
            LIMIT 1
        `;
        
        const checkResult = await pool.query(checkQuery, [employeeId, today]);
        console.log('Check result rows:', checkResult.rows);
        
        if (checkResult.rows.length === 0) {
            throw new Error('No check-in found for today');
        }
        
        const attendanceRecord = checkResult.rows[0];
        
        if (attendanceRecord.check_out) {
            throw new Error(`Already checked out at ${new Date(attendanceRecord.check_out).toLocaleTimeString()}`);
        }
        
        // Update check-out
        const updateQuery = `
            UPDATE attendance 
            SET check_out = CURRENT_TIMESTAMP 
            WHERE id = $1 
            AND check_out IS NULL
            RETURNING *
        `;
        
        const result = await pool.query(updateQuery, [attendanceRecord.id]);
        
        if (result.rows.length === 0) {
            throw new Error('Failed to update check-out');
        }
        
        console.log(`✅ Check-out recorded for employee ID: ${employeeId} at ${result.rows[0].check_out}`);
        return result.rows[0];
        
    } catch (error) {
        console.error('Error during check-out:', error);
        throw error;
    }
}
     

 // =========== DATE HELPER FUNCTION ===========
static getTodayDate() {
    // Get date in YYYY-MM-DD format, considering timezone
    const now = new Date();
    // Adjust for timezone offset
    const offset = now.getTimezoneOffset() * 60000; // Convert minutes to milliseconds
    const localDate = new Date(now.getTime() - offset);
    return localDate.toISOString().split('T')[0];
}



// =========== CHECK IN ===========
static async checkIn(attendanceData) {
    const {
        employee_id,
        gps_lat,
        gps_lng,
        face_verified = false,
        location_verified = false
    } = attendanceData;
    
    try {
        const today = this.getTodayDate();
        console.log(`=== CHECK IN DEBUG ===`);
        console.log(`Today's date: ${today}`);
        console.log(`Employee ID: ${employee_id}`);
        
        // Check if already checked in TODAY and NOT checked out
        const existingQuery = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') = $2
            AND check_out IS NULL
        `;
        
        const existingResult = await pool.query(existingQuery, [employee_id, today]);
        console.log(`Existing check-ins today: ${existingResult.rows.length}`);
        
        if (existingResult.rows.length > 0) {
            const existing = existingResult.rows[0];
            throw new Error(`Already checked in at ${new Date(existing.check_in).toLocaleTimeString()}. Check out first.`);
        }
        
        // Also check if checked in and checked out today (prevent re-check-in)
        const completedQuery = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') = $2
            AND check_out IS NOT NULL
        `;
        
        const completedResult = await pool.query(completedQuery, [employee_id, today]);
        console.log(`Completed check-ins today: ${completedResult.rows.length}`);
        
        if (completedResult.rows.length > 0) {
            throw new Error('Already checked in and out for today');
        }
        
        // Insert new check-in
        const insertQuery = `
            INSERT INTO attendance 
            (employee_id, gps_lat, gps_lng, face_verified, location_verified, check_in)
            VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
            RETURNING *
        `;
        
        const values = [employee_id, gps_lat, gps_lng, face_verified, location_verified];
        const result = await pool.query(insertQuery, values);
        
        console.log(`✅ Check-in recorded for employee ID: ${employee_id} at ${result.rows[0].check_in}`);
        return result.rows[0];
        
    } catch (error) {
        console.error('Error during check-in:', error);
        throw error;
    }
}

// =========== CHECK OUT ===========
static async checkOut(employeeId) {
    try {
        const today = this.getTodayDate();
        console.log(`=== CHECK OUT DEBUG ===`);
        console.log(`Today's date: ${today}`);
        console.log(`Employee ID: ${employeeId}`);
        
        // Find today's check-in that hasn't been checked out
        const query = `
            SELECT * FROM attendance 
            WHERE employee_id = $1 
            AND DATE(check_in AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') = $2
            AND check_out IS NULL
            ORDER BY check_in DESC
            LIMIT 1
        `;
        
        console.log(`Query: Looking for check-in on ${today}`);
        const result = await pool.query(query, [employeeId, today]);
        console.log(`Found records: ${result.rows.length}`);
        
        if (result.rows.length === 0) {
            // Try yesterday too, in case timezone issue
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = this.getTodayDate(yesterday);
            
            console.log(`Trying yesterday: ${yesterdayStr}`);
            const yesterdayQuery = `
                SELECT * FROM attendance 
                WHERE employee_id = $1 
                AND DATE(check_in AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Kolkata') = $2
                AND check_out IS NULL
                ORDER BY check_in DESC
                LIMIT 1
            `;
            
            const yesterdayResult = await pool.query(yesterdayQuery, [employeeId, yesterdayStr]);
            console.log(`Yesterday records: ${yesterdayResult.rows.length}`);
            
            if (yesterdayResult.rows.length === 0) {
                throw new Error('No active check-in found for today or yesterday');
            }
            
            // Use yesterday's record
            const attendanceRecord = yesterdayResult.rows[0];
            
            // Update check-out
            const updateQuery = `
                UPDATE attendance 
                SET check_out = CURRENT_TIMESTAMP 
                WHERE id = $1 
                AND check_out IS NULL
                RETURNING *
            `;
            
            const updateResult = await pool.query(updateQuery, [attendanceRecord.id]);
            console.log(`✅ Check-out recorded from yesterday's check-in`);
            return updateResult.rows[0];
        }
        
        const attendanceRecord = result.rows[0];
        
        // Update check-out
        const updateQuery = `
            UPDATE attendance 
            SET check_out = CURRENT_TIMESTAMP 
            WHERE id = $1 
            AND check_out IS NULL
            RETURNING *
        `;
        
        const updateResult = await pool.query(updateQuery, [attendanceRecord.id]);
        
        if (updateResult.rows.length === 0) {
            throw new Error('Failed to update check-out');
        }
        
        console.log(`✅ Check-out recorded for employee ID: ${employeeId} at ${updateResult.rows[0].check_out}`);
        return updateResult.rows[0];
        
    } catch (error) {
        console.error('Error during check-out:', error);
        throw error;
    }
}

// Add this helper method
static getTodayDate(date = new Date()) {
    // Get date in YYYY-MM-DD format in local timezone
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}
    
    // =========== FIND TODAY'S ATTENDANCE ===========
    static async findTodayAttendance(employee_id) {
    const query = `
        SELECT *
        FROM attendance
        WHERE employee_id = $1
          AND check_in >= CURRENT_DATE
          AND check_in < CURRENT_DATE + INTERVAL '1 day'
        ORDER BY check_in DESC
        LIMIT 1
    `;

    const result = await db.query(query, [employee_id]);
    return result.rows[0] || null;
}


 
    
    // =========== GET EMPLOYEE ATTENDANCE HISTORY ===========
    static async getEmployeeHistory(employeeId, startDate = null, endDate = null) {
        try {
            let query = `
                SELECT a.*, e.full_name, e.employee_id as emp_code
                FROM attendance a
                JOIN employees e ON a.employee_id = e.id
                WHERE a.employee_id = $1
            `;
            
            const values = [employeeId];
            let paramCount = 1;
            
            if (startDate) {
                paramCount++;
                query += ` AND DATE(a.check_in) >= $${paramCount}`;
                values.push(startDate);
            }
            
            if (endDate) {
                paramCount++;
                query += ` AND DATE(a.check_in) <= $${paramCount}`;
                values.push(endDate);
            }
            
            query += ` ORDER BY a.check_in DESC`;
            
            const result = await pool.query(query, values);
            return result.rows;
            
        } catch (error) {
            console.error('Error getting employee history:', error);
            throw error;
        }
    }
    
    // =========== GET ALL ATTENDANCE (ADMIN) ===========
    static async getAll(startDate = null, endDate = null, limit = 100, offset = 0) {
        try {
            let query = `
                SELECT a.*, e.full_name, e.employee_id as emp_code, e.email
                FROM attendance a
                JOIN employees e ON a.employee_id = e.id
                WHERE 1=1
            `;
            
            const values = [];
            let paramCount = 0;
            
            if (startDate) {
                paramCount++;
                query += ` AND DATE(a.check_in) >= $${paramCount}`;
                values.push(startDate);
            }
            
            if (endDate) {
                paramCount++;
                query += ` AND DATE(a.check_in) <= $${paramCount}`;
                values.push(endDate);
            }
            
            query += ` ORDER BY a.check_in DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
            values.push(limit, offset);
            
            const result = await pool.query(query, values);
            return result.rows;
            
        } catch (error) {
            console.error('Error getting all attendance:', error);
            throw error;
        }
    }
    
    // =========== CALCULATE WORK HOURS ===========
    static async calculateWorkHours(employeeId, date) {
        try {
            const query = `
                SELECT 
                    check_in,
                    check_out,
                    EXTRACT(EPOCH FROM (check_out - check_in))/3600 as hours_worked
                FROM attendance 
                WHERE employee_id = $1 
                AND DATE(check_in) = $2
                AND check_out IS NOT NULL
            `;
            
            const result = await pool.query(query, [employeeId, date]);
            return result.rows;
            
        } catch (error) {
            console.error('Error calculating work hours:', error);
            throw error;
        }
    }
}

// =========== EXPORT THE CLASS ===========
export default Attendance;

*/