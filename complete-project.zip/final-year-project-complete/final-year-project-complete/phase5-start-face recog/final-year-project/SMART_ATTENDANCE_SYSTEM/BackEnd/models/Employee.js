// =========== IMPORT DEPENDENCIES ===========
import pool from '../config/db.js';
import bcrypt from 'bcryptjs';

// =========== EMPLOYEE CLASS ===========
// Using ES6 Class syntax for better organization
class Employee {
    // =========== CREATE NEW EMPLOYEE ===========
    static async create(employeeData) {
        const { employee_id, full_name, email, password } = employeeData;
        
        // Validate input
        if (!employee_id || !full_name || !email || !password) {
            throw new Error('All fields are required');
        }
        
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            throw new Error('Invalid email format');
        }
        
        try {
            // Hash password for security (never store plain passwords!)
            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(password, saltRounds);
            
            const query = `
                INSERT INTO employees 
                (employee_id, full_name, email, password_hash, created_at) 
                VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP) 
                RETURNING id, employee_id, full_name, email, created_at
            `;
            
            const values = [employee_id, full_name, email, hashedPassword];
            const result = await pool.query(query, values);
            
            console.log(`✅ Employee created: ${employee_id} - ${full_name}`);
            return result.rows[0];
            
        } catch (error) {
            // Handle duplicate email or employee_id
            if (error.code === '23505') { // PostgreSQL unique violation
                if (error.constraint.includes('email')) {
                    throw new Error('Email already exists');
                } else if (error.constraint.includes('employee_id')) {
                    throw new Error('Employee ID already exists');
                }
            }
            throw error;
        }
    }
    
    // =========== FIND EMPLOYEE BY EMAIL ===========
    static async findByEmail(email) {
        try {
            const query = `
                SELECT id, employee_id, full_name, email, password_hash, 
                       face_encoding, created_at, is_active, last_login
                FROM employees 
                WHERE email = $1 AND is_active = true
            `;
            
            const result = await pool.query(query, [email]);
            
            if (result.rows.length === 0) {
                return null;
            }
            
            return result.rows[0];
            
        } catch (error) {
            console.error('Error finding employee by email:', error);
            throw error;
        }
    }

        // =========== FIND EMPLOYEE BY EMPLOYEE ID ===========
    static async findByEmployeeId(employeeId) {
        try {
            const query = `
                SELECT id, employee_id, full_name, email, 
                       face_encoding, created_at, is_active
                FROM employees 
                WHERE employee_id = $1 AND is_active = true
            `;
            
            const result = await pool.query(query, [employeeId]);
            
            if (result.rows.length === 0) {
                return null;
            }
            
            return result.rows[0];
            
        } catch (error) {
            console.error('Error finding employee by ID:', error);
            throw error;
        }
    }
    
    // =========== FIND EMPLOYEE BY ID 8888SUS8888 ===========
    static async findById(id) {
        try {
            const query = `
                SELECT id, employee_id, full_name, email, 
                       face_encoding, created_at, is_active
                FROM employees 
                WHERE id = $1 AND is_active = true
            `;
            
            const result = await pool.query(query, [id]);
            return result.rows[0];
            
        } catch (error) {
            console.error('Error finding employee by ID:', error);
            throw error;
        }
    }
    
    // =========== UPDATE FACE ENCODING ===========
// =========== UPDATE FACE ENCODING ===========
static async updateFaceEncoding(employeeId, faceEncoding) {
    try {
        console.log(`🔄 Updating face encoding for employee: ${employeeId}`);
        console.log(`Face encoding type: ${typeof faceEncoding}`);
        console.log(`Face encoding length: ${faceEncoding ? faceEncoding.length : 'null'}`);
        
        // If it's an array, convert to JSON string
        let faceData = faceEncoding;
        if (Array.isArray(faceEncoding)) {
            faceData = JSON.stringify(faceEncoding);
            console.log(`Converted array to JSON string, length: ${faceData.length}`);
        }
        
        const query = `
            UPDATE employees 
            SET face_encoding = $1 
            WHERE employee_id = $2 
            RETURNING employee_id, full_name, email
        `;
        
        const result = await pool.query(query, [faceData, employeeId]);
        
        if (result.rows.length === 0) {
            throw new Error(`Employee with ID "${employeeId}" not found`);
        }
        
        console.log(`✅ Face encoding updated for: ${result.rows[0].full_name}`);
        return result.rows[0];
        
    } catch (error) {
        console.error('❌ Error updating face encoding:', error);
        console.error('SQL Error details:', {
            message: error.message,
            code: error.code,
            detail: error.detail,
            hint: error.hint
        });
        throw error;
    }
}
    
    // =========== UPDATE LAST LOGIN ===========
    static async updateLastLogin(employeeId) {
        try {
            const query = `
                UPDATE employees 
                SET last_login = CURRENT_TIMESTAMP 
                WHERE id = $1
            `;
            
            await pool.query(query, [employeeId]);
            
        } catch (error) {
            console.error('Error updating last login:', error);
            // Don't throw error - this is non-critical
        }
    }
    
    // =========== VERIFY PASSWORD ===========
    // =========== VERIFY PASSWORD ===========
static async verifyPassword(plainPassword, hashedPassword) {
    try {
        // Check if hashedPassword exists
        if (!hashedPassword) {
            console.error('verifyPassword: hashedPassword is null or undefined');
            return false;
        }
        
        return await bcrypt.compare(plainPassword, hashedPassword);
    } catch (error) {
        console.error('Error verifying password:', error);
        return false;
    }
}
    
    // =========== GET ALL EMPLOYEES ===========
    static async getAll(limit = 100, offset = 0) {
        try {
            const query = `
                SELECT id, employee_id, full_name, email, 
                       created_at, last_login, is_active
                FROM employees 
                WHERE is_active = true
                ORDER BY created_at DESC
                LIMIT $1 OFFSET $2
            `;
            
            const result = await pool.query(query, [limit, offset]);
            return result.rows;
            
        } catch (error) {
            console.error('Error getting all employees:', error);
            throw error;
        }
    }
    
    // =========== DEACTIVATE EMPLOYEE ===========
    static async deactivate(employeeId) {
        try {
            const query = `
                UPDATE employees 
                SET is_active = false 
                WHERE id = $1 
                RETURNING employee_id, full_name
            `;
            
            const result = await pool.query(query, [employeeId]);
            return result.rows[0];
            
        } catch (error) {
            console.error('Error deactivating employee:', error);
            throw error;
        }
    }
}

// =========== EXPORT THE CLASS ===========
export default Employee;