// =========== DATABASE CONFIGURATION ===========
// ES6 Module import
import pkg from 'pg';
const { Pool } = pkg;
import dotenv from 'dotenv';

dotenv.config();

// =========== CREATE DATABASE POOL ===========
// Pool manages multiple database connections efficiently
const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'attendance_system',
    password: process.env.DB_PASSWORD || '',
    port: process.env.DB_PORT || 5432,
    max: 20, // Maximum number of clients in pool
    idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
    connectionTimeoutMillis: 2000, // Return error if can't connect in 2 seconds
});

// =========== EVENT LISTENERS FOR POOL ===========
// Monitor database connection events

pool.on('connect', () => {
    console.log('✅ Database connection established');
});

pool.on('error', (err) => {
    console.error('❌ Unexpected database error:', err);
    // In production, you might want to reconnect or alert admins
});

pool.on('remove', () => {
    console.log('🔌 Database connection removed');
});

// =========== TEST CONNECTION FUNCTION ===========
// Utility to verify database is working
export async function testConnection() {
    try {
        const client = await pool.connect();
        console.log('📊 Database connection test: SUCCESS');
        
        const result = await client.query('SELECT NOW() as current_time');
        console.log('🕒 Database time:', result.rows[0].current_time);
        
        client.release();
        return true;
    } catch (error) {
        console.error('❌ Database connection test: FAILED', error.message);
        return false;
    }
}

// =========== QUERY HELPER FUNCTION ===========
// Wrapper for pool.query with error handling
export async function query(text, params) {
    const start = Date.now();
    
    try {
        const result = await pool.query(text, params);
        const duration = Date.now() - start;
        
        // Log slow queries (for debugging)
        if (duration > 100) {
            console.log(`🐢 Slow query: ${text} took ${duration}ms`);
        }
        
        return result;
    } catch (error) {
        console.error('🔥 Database query error:', {
            query: text,
            params: params,
            error: error.message
        });
        throw error;
    }
}

// =========== GET CLIENT FOR TRANSACTIONS ===========
// Use this when you need multiple queries in a transaction
export async function getClient() {
    const client = await pool.connect();
    
    // Monkey-patch the query method to track duration
    const originalQuery = client.query;
    const originalRelease = client.release;
    
    const release = () => {
        // Reset the methods before release
        client.query = originalQuery;
        client.release = originalRelease;
        return originalRelease.apply(client);
    };
    
    // Set a timeout of 5 seconds for this client
    const timeout = setTimeout(() => {
        console.error('⏰ Client held for too long (>5 seconds)');
    }, 5000);
    
    client.release = () => {
        clearTimeout(timeout);
        return release();
    };
    
    return client;
}

// =========== DEFAULT EXPORT ===========
// Export the pool for direct use if needed
export default pool;