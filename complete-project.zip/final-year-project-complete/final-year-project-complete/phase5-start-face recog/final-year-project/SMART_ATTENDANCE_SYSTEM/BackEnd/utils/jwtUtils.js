// =========== IMPORT DEPENDENCIES ===========
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';

dotenv.config();

// =========== JWT CONFIGURATION ===========
const JWT_CONFIG = {
    expiresIn: '8h', // Token expires in 8 hours
    issuer: 'attendance-system',
    audience: 'employee-portal'
};

// =========== GENERATE TOKEN ===========
/**
 * Creates a JWT token for authenticated users
 * @param {Object} user - User object from database
 * @param {string} role - User role (employee/admin)
 * @returns {string} JWT token
 */
export function generateToken(user, role = 'employee') {
    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET not configured in environment variables');
    }
    
    const payload = {
        id: user.id,
        employee_id: user.employee_id,
        email: user.email,
        name: user.full_name,
        role: role,
        iat: Math.floor(Date.now() / 1000) // Issued at
    };
    
    return jwt.sign(payload, process.env.JWT_SECRET, JWT_CONFIG);
}

// =========== VERIFY TOKEN ===========
/**
 * Verifies and decodes a JWT token
 * @param {string} token - JWT token from request header
 * @returns {Object|null} Decoded token payload or null if invalid
 */
export function verifyToken(token) {
    try {
        if (!token) {
            console.warn('No token provided');
            return null;
        }
        
        // Remove 'Bearer ' prefix if present
        const tokenWithoutBearer = token.startsWith('Bearer ') 
            ? token.slice(7) 
            : token;
        
        return jwt.verify(tokenWithoutBearer, process.env.JWT_SECRET, {
            issuer: JWT_CONFIG.issuer,
            audience: JWT_CONFIG.audience
        });
        
    } catch (error) {
        console.error('Token verification failed:', error.message);
        
        // Different error messages for different failures
        if (error.name === 'TokenExpiredError') {
            console.warn('Token has expired');
        } else if (error.name === 'JsonWebTokenError') {
            console.warn('Invalid token format');
        }
        
        return null;
    }
}

// =========== AUTHENTICATION MIDDLEWARE ===========
/**
 * Express middleware to protect routes
 * @param {string} allowedRole - Role required to access (employee/admin)
 * @returns {Function} Express middleware function
 *
export function authenticate(allowedRole = 'employee') {
    return (req, res, next) => {
        try {
            // Get token from Authorization header
            const authHeader = req.headers.authorization;
            
            if (!authHeader) {
                return res.status(401).json({
                    success: false,
                    message: 'Access denied. No token provided.'
                });
            }
            
            const decoded = verifyToken(authHeader);
            
            if (!decoded) {
                return res.status(401).json({
                    success: false,
                    message: 'Invalid or expired token'
                });
            }
            
             // Add role check (if you don't have it already)
        if (requiredRole === 'admin' && decoded.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Admin access required'
            });
        }
            
            // Attach user info to request object
            req.user = {
                id: decoded.id,
                employee_id: decoded.employee_id,
                email: decoded.email,
                name: decoded.name,
                role: decoded.role
            };
            
            console.log(`✅ Authenticated: ${decoded.name} (${decoded.role})`);
            next();
            
        } catch (error) {
            console.error('Authentication error:', error);
            return res.status(500).json({
                success: false,
                message: 'Internal server error during authentication'
            });
        }
    };
}
*/
// =========== AUTHENTICATION MIDDLEWARE ===========
/**
 * Express middleware to protect routes
 * @param {string} allowedRole - Role required to access (employee/admin)
 * @returns {Function} Express middleware function
 */
export function authenticate(allowedRole = 'employee') {
    return (req, res, next) => {
        try {
            // Get token from Authorization header
            const authHeader = req.headers.authorization;
            
            if (!authHeader) {
                return res.status(401).json({
                    success: false,
                    message: 'Access denied. No token provided.'
                });
            }
            
            const decoded = verifyToken(authHeader);
            
            if (!decoded) {
                return res.status(401).json({
                    success: false,
                    message: 'Invalid or expired token'
                });
            }
            
            // ✅ FIXED: Change "requiredRole" to "allowedRole"
            if (allowedRole === 'admin' && decoded.role !== 'admin') {
                return res.status(403).json({
                    success: false,
                    message: 'Admin access required'
                });
            }
            
            // Attach user info to request object
            req.user = {
                id: decoded.id,
                employee_id: decoded.employee_id,
                email: decoded.email,
                name: decoded.name,
                role: decoded.role
            };
            
            console.log(`✅ Authenticated: ${decoded.name} (${decoded.role})`);
            next();
            
        } catch (error) {
            console.error('Authentication error:', error);
            return res.status(500).json({
                success: false,
                message: 'Internal server error during authentication'
            });
        }
    };
}
// =========== GENERATE RANDOM PASSWORD ===========
/**
 * Generates a random password for new employees
 * @returns {string} Random password
 */
export function generateRandomPassword(length = 8) {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    let password = '';
    
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }
    
    return password;
}

// =========== TOKEN BLACKLIST (Simple in-memory) ===========
// In production, use Redis for this
const tokenBlacklist = new Set();

/**
 * Adds token to blacklist (for logout)
 * @param {string} token - Token to blacklist
 */
export function blacklistToken(token) {
    tokenBlacklist.add(token);
    console.log(`Token blacklisted. Total: ${tokenBlacklist.size}`);
}

/**
 * Checks if token is blacklisted
 * @param {string} token - Token to check
 * @returns {boolean} True if blacklisted
 */
export function isTokenBlacklisted(token) {
    return tokenBlacklist.has(token);
}