// =========== GPS UTILITY FUNCTIONS ===========
import dotenv from 'dotenv';
dotenv.config();

// =========== CONFIGURATION ===========
const OFFICE_CONFIG = {
    LAT: parseFloat(process.env.OFFICE_LAT) || 13.1262,
    LNG: parseFloat(process.env.OFFICE_LNG) || 80.2335,
    RADIUS: parseFloat(process.env.OFFICE_RADIUS_METERS) || 100 // meters
};

// =========== CALCULATE DISTANCE ===========
/**
 * Calculate distance between two GPS points using Haversine formula
 * @param {number} lat1 - Latitude of point 1
 * @param {number} lon1 - Longitude of point 1
 * @param {number} lat2 - Latitude of point 2
 * @param {number} lon2 - Longitude of point 2
 * @returns {number} Distance in meters
 */
export function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371000; // Earth's radius in meters
    
    // Convert degrees to radians
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;
    
    // Haversine formula
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distance in meters
    
    return Math.round(distance * 100) / 100; // Round to 2 decimal places
}

// =========== VERIFY LOCATION ===========
/**
 * Check if location is within office radius
 * @param {number} userLat - User's latitude
 * @param {number} userLng - User's longitude
 * @returns {Object} Verification result
 */
export function verifyLocation(userLat, userLng) {
    try {
        if (!userLat || !userLng) {
            throw new Error('Invalid GPS coordinates');
        }
        
        // Calculate distance
        const distance = calculateDistance(
            userLat, userLng,
            OFFICE_CONFIG.LAT, OFFICE_CONFIG.LNG
        );
        
        // Check if within allowed radius
        const isWithinRadius = distance <= OFFICE_CONFIG.RADIUS;
        
        return {
            success: true,
            is_within_radius: isWithinRadius,
            distance: distance,
            max_allowed: OFFICE_CONFIG.RADIUS,
            office_location: {
                lat: OFFICE_CONFIG.LAT,
                lng: OFFICE_CONFIG.LNG
            },
            user_location: {
                lat: userLat,
                lng: userLng
            },
            message: isWithinRadius 
                ? `Within office radius (${distance}m / ${OFFICE_CONFIG.RADIUS}m)` 
                : `Too far from office (${distance}m / ${OFFICE_CONFIG.RADIUS}m)`
        };
        
    } catch (error) {
        return {
            success: false,
            is_within_radius: false,
            distance: null,
            message: error.message || 'Location verification failed'
        };
    }
}

// =========== GET OFFICE INFO ===========
export function getOfficeInfo() {
    return {
        lat: OFFICE_CONFIG.LAT,
        lng: OFFICE_CONFIG.LNG,
        radius: OFFICE_CONFIG.RADIUS,
        address: process.env.OFFICE_ADDRESS || 'Office Location'
    };
}

// =========== FORMAT DISTANCE ===========
export function formatDistance(meters) {
    if (meters < 1000) {
        return `${meters} meters`;
    } else {
        const km = meters / 1000;
        return `${km.toFixed(2)} km`;
    }
}