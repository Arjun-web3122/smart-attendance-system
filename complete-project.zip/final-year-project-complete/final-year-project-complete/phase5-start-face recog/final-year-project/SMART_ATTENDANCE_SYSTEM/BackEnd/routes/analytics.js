// =========== SIMPLE ANALYTICS ROUTES ===========
// NO CHARTS - Just tables and numbers
import express from 'express';
import pool from '../config/db.js';

const router = express.Router();

// =========== DAILY ATTENDANCE REPORT ===========
/**
 * @route GET /api/admin/analytics/daily
 * @desc Get daily attendance for all or specific employee
 * @query date=YYYY-MM-DD (optional, defaults to today)
 * @query employeeId=EMP001 (optional, for specific employee)
 */
router.get('/daily', async (req, res) => {
    try {
        const { date, employeeId } = req.query;
        
        // Use today if no date provided
        const targetDate = date || new Date().toISOString().split('T')[0];
        
        console.log(`📅 Daily report for date: ${targetDate}`, employeeId ? `Employee: ${employeeId}` : 'All employees');
        
        // Build query
        let query = `
            SELECT 
                a.id,
                a.check_in,
                a.check_out,
                a.gps_lat,
                a.gps_lng,
                a.face_verified,
                a.location_verified,
                a.status,
                e.employee_id as emp_code,
                e.full_name,
                e.email
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE DATE(a.check_in) = $1
            AND e.is_active = true
        `;
        
        let values = [targetDate];
        
        // Add employee filter if provided
        if (employeeId) {
            query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
            values.push(`%${employeeId}%`);
        }
        
        query += ` ORDER BY a.check_in DESC`;
        
        // Execute query
        const result = await pool.query(query, values);
        
        // Calculate summary statistics
        const summary = calculateDailySummary(result.rows);
        
        res.json({
            success: true,
            date: targetDate,
            employee_filter: employeeId || 'All employees',
            attendance: result.rows,
            summary: summary,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Daily analytics error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate daily report'
        });
    }
});

// =========== MONTHLY ATTENDANCE REPORT ===========
/**
 * @route GET /api/admin/analytics/monthly
 * @desc Get monthly attendance for all or specific employee
 * @query month=YYYY-MM (optional, defaults to current month)
 * @query employeeId=EMP001 (optional)
 */
router.get('/monthly', async (req, res) => {
    try {
        const { month, employeeId } = req.query;
        
        // Use current month if not provided
        let targetMonth = month;
        if (!targetMonth) {
            const now = new Date();
            targetMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        }
        
        console.log(`📅 Monthly report for: ${targetMonth}`, employeeId ? `Employee: ${employeeId}` : 'All employees');
        
        // Build query - Group by date and employee
        let query = `
            SELECT 
                DATE(a.check_in) as attendance_date,
                e.employee_id as emp_code,
                e.full_name,
                COUNT(DISTINCT DATE(a.check_in)) as days_present,
                MIN(a.check_in) as first_checkin,
                MAX(a.check_out) as last_checkout,
                AVG(EXTRACT(EPOCH FROM (a.check_out - a.check_in))/3600) as avg_hours
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE TO_CHAR(a.check_in, 'YYYY-MM') = $1
            AND e.is_active = true
        `;
        
        let values = [targetMonth];
        
        // Add employee filter if provided
        if (employeeId) {
            query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
            values.push(`%${employeeId}%`);
        }
        
        query += ` 
            GROUP BY DATE(a.check_in), e.employee_id, e.full_name
            ORDER BY attendance_date DESC, e.full_name
        `;
        
        // Execute query
        const result = await pool.query(query, values);
        
        // Calculate monthly summary
        const summary = calculateMonthlySummary(result.rows);
        
        res.json({
            success: true,
            month: targetMonth,
            employee_filter: employeeId || 'All employees',
            attendance: result.rows,
            summary: summary,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Monthly analytics error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate monthly report'
        });
    }
});

// =========== YEARLY ATTENDANCE REPORT ===========
/**
 * @route GET /api/admin/analytics/yearly
 * @desc Get yearly attendance for all or specific employee
 * @query year=2025 (optional, defaults to current year)
 * @query employeeId=EMP001 (optional)
 */
router.get('/yearly', async (req, res) => {
    try {
        const { year, employeeId } = req.query;
        
        // Use current year if not provided
        let targetYear = year || new Date().getFullYear().toString();
        
        console.log(`📅 Yearly report for: ${targetYear}`, employeeId ? `Employee: ${employeeId}` : 'All employees');
        
        // Build query - Group by month and employee
        let query = `
            SELECT 
                TO_CHAR(a.check_in, 'YYYY-MM') as month,
                e.employee_id as emp_code,
                e.full_name,
                COUNT(DISTINCT DATE(a.check_in)) as days_present,
                AVG(EXTRACT(EPOCH FROM (a.check_out - a.check_in))/3600) as avg_hours
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE EXTRACT(YEAR FROM a.check_in) = $1
            AND e.is_active = true
        `;
        
        let values = [targetYear];
        
        // Add employee filter if provided
        if (employeeId) {
            query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
            values.push(`%${employeeId}%`);
        }
        
        query += ` 
            GROUP BY TO_CHAR(a.check_in, 'YYYY-MM'), e.employee_id, e.full_name
            ORDER BY month DESC, e.full_name
        `;
        
        // Execute query
        const result = await pool.query(query, values);
        
        // Calculate yearly summary
        const summary = calculateYearlySummary(result.rows);
        
        res.json({
            success: true,
            year: targetYear,
            employee_filter: employeeId || 'All employees',
            attendance: result.rows,
            summary: summary,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Yearly analytics error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate yearly report'
        });
    }
});

// =========== SEARCH EMPLOYEES ===========
/**
 * @route GET /api/admin/analytics/employees
 * @desc Search employees by name or ID for dropdown
 * @query search=john (optional)
 */
router.get('/employees', async (req, res) => {
    try {
        const { search } = req.query;
        
        let query = `
            SELECT employee_id, full_name, email
            FROM employees
            WHERE is_active = true
        `;
        
        let values = [];
        
        if (search) {
            query += ` AND (full_name ILIKE $1 OR employee_id ILIKE $1)`;
            values.push(`%${search}%`);
        }
        
        query += ` ORDER BY full_name LIMIT 50`;
        
        const result = await pool.query(query, values);
        
        res.json({
            success: true,
            employees: result.rows,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Employee search error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to search employees'
        });
    }
});

// =========== EXPORT ANALYTICS DATA ===========
/**
 * @route GET /api/admin/analytics/export
 * @desc Export analytics data as CSV
 * @query type=daily|monthly|yearly
 * @query date=YYYY-MM-DD (for daily)
 * @query month=YYYY-MM (for monthly)
 * @query year=2025 (for yearly)
 * @query employeeId=EMP001 (optional)
 */
router.get('/export', async (req, res) => {
    try {
        const { type, date, month, year, employeeId } = req.query;
        
        if (!type) {
            return res.status(400).json({
                success: false,
                message: 'Report type is required'
            });
        }
        
        let query, filename, dateParam;
        
        switch(type) {
            case 'daily':
                dateParam = date || new Date().toISOString().split('T')[0];
                query = buildDailyQuery(employeeId);
                filename = `attendance_daily_${dateParam}.csv`;
                break;
                
            case 'monthly':
                if (!month) {
                    const now = new Date();
                    dateParam = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                } else {
                    dateParam = month;
                }
                query = buildMonthlyQuery(employeeId);
                filename = `attendance_monthly_${dateParam}.csv`;
                break;
                
            case 'yearly':
                dateParam = year || new Date().getFullYear().toString();
                query = buildYearlyQuery(employeeId);
                filename = `attendance_yearly_${dateParam}.csv`;
                break;
                
            default:
                return res.status(400).json({
                    success: false,
                    message: 'Invalid report type'
                });
        }
        
        // Add date filter to query
        let values = [];
        if (type === 'daily') {
            values.push(dateParam);
        } else if (type === 'monthly') {
            values.push(dateParam);
        } else if (type === 'yearly') {
            values.push(dateParam);
        }
        
        if (employeeId) {
            values.push(`%${employeeId}%`);
        }
        
        // Execute query
        const result = await pool.query(query, values);
        
        // Convert to CSV
        const csvContent = convertToCSV(result.rows);
        
        res.json({
            success: true,
            csv: csvContent,
            filename: filename,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Export error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to export data'
        });
    }
});

// =========== HELPER FUNCTIONS ===========

function calculateDailySummary(attendance) {
    if (!attendance || attendance.length === 0) {
        return {
            total_employees: 0,
            total_checkins: 0,
            face_verified: 0,
            location_verified: 0,
            avg_hours: 0
        };
    }
    
    // Calculate statistics
    const totalEmployees = new Set(attendance.map(a => a.emp_code)).size;
    const totalCheckins = attendance.length;
    const faceVerified = attendance.filter(a => a.face_verified).length;
    const locationVerified = attendance.filter(a => a.location_verified).length;
    
    // Calculate average hours for those checked out
    const checkedOut = attendance.filter(a => a.check_out);
    let avgHours = 0;
    if (checkedOut.length > 0) {
        const totalHours = checkedOut.reduce((sum, record) => {
            const start = new Date(record.check_in);
            const end = new Date(record.check_out);
            return sum + (end - start) / (1000 * 60 * 60);
        }, 0);
        avgHours = totalHours / checkedOut.length;
    }
    
    return {
        total_employees: totalEmployees,
        total_checkins: totalCheckins,
        face_verified: faceVerified,
        location_verified: locationVerified,
        avg_hours: avgHours.toFixed(2)
    };
}

function calculateMonthlySummary(attendance) {
    if (!attendance || attendance.length === 0) {
        return {
            total_days: 0,
            total_employees: 0,
            total_records: 0,
            avg_hours: 0
        };
    }
    
    const totalDays = new Set(attendance.map(a => a.attendance_date)).size;
    const totalEmployees = new Set(attendance.map(a => a.emp_code)).size;
    const totalRecords = attendance.length;
    
    // Calculate average hours
    let totalHours = 0;
    let count = 0;
    
    attendance.forEach(record => {
        if (record.avg_hours) {
            totalHours += parseFloat(record.avg_hours);
            count++;
        }
    });
    
    const avgHours = count > 0 ? (totalHours / count) : 0;
    
    return {
        total_days: totalDays,
        total_employees: totalEmployees,
        total_records: totalRecords,
        avg_hours: avgHours.toFixed(2)
    };
}

function calculateYearlySummary(attendance) {
    if (!attendance || attendance.length === 0) {
        return {
            total_months: 0,
            total_employees: 0,
            total_days: 0,
            avg_hours: 0
        };
    }
    
    const totalMonths = new Set(attendance.map(a => a.month)).size;
    const totalEmployees = new Set(attendance.map(a => a.emp_code)).size;
    
    // Sum all days
    const totalDays = attendance.reduce((sum, record) => {
        return sum + (record.days_present || 0);
    }, 0);
    
    // Calculate average hours
    let totalHours = 0;
    let count = 0;
    
    attendance.forEach(record => {
        if (record.avg_hours) {
            totalHours += parseFloat(record.avg_hours);
            count++;
        }
    });
    
    const avgHours = count > 0 ? (totalHours / count) : 0;
    
    return {
        total_months: totalMonths,
        total_employees: totalEmployees,
        total_days: totalDays,
        avg_hours: avgHours.toFixed(2)
    };
}

function buildDailyQuery(employeeId) {
    let query = `
        SELECT 
            e.employee_id,
            e.full_name,
            e.email,
            TO_CHAR(a.check_in, 'YYYY-MM-DD') as date,
            TO_CHAR(a.check_in, 'HH24:MI:SS') as check_in_time,
            TO_CHAR(a.check_out, 'HH24:MI:SS') as check_out_time,
            EXTRACT(EPOCH FROM (a.check_out - a.check_in))/3600 as hours_worked,
            a.gps_lat,
            a.gps_lng,
            a.face_verified,
            a.location_verified,
            a.status
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE DATE(a.check_in) = $1
        AND e.is_active = true
    `;
    
    if (employeeId) {
        query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
    }
    
    query += ` ORDER BY a.check_in DESC`;
    
    return query;
}

function buildMonthlyQuery(employeeId) {
    let query = `
        SELECT 
            e.employee_id,
            e.full_name,
            e.email,
            TO_CHAR(a.check_in, 'YYYY-MM-DD') as date,
            TO_CHAR(a.check_in, 'HH24:MI:SS') as check_in_time,
            TO_CHAR(a.check_out, 'HH24:MI:SS') as check_out_time,
            EXTRACT(EPOCH FROM (a.check_out - a.check_in))/3600 as hours_worked,
            a.gps_lat,
            a.gps_lng,
            a.face_verified,
            a.location_verified,
            a.status
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE TO_CHAR(a.check_in, 'YYYY-MM') = $1
        AND e.is_active = true
    `;
    
    if (employeeId) {
        query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
    }
    
    query += ` ORDER BY a.check_in DESC`;
    
    return query;
}

function buildYearlyQuery(employeeId) {
    let query = `
        SELECT 
            e.employee_id,
            e.full_name,
            TO_CHAR(a.check_in, 'YYYY-MM') as month,
            COUNT(DISTINCT DATE(a.check_in)) as days_present,
            AVG(EXTRACT(EPOCH FROM (a.check_out - a.check_in))/3600) as avg_hours
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE EXTRACT(YEAR FROM a.check_in) = $1
        AND e.is_active = true
    `;
    
    if (employeeId) {
        query += ` AND (e.employee_id ILIKE $2 OR e.full_name ILIKE $2)`;
    }
    
    query += ` 
        GROUP BY e.employee_id, e.full_name, TO_CHAR(a.check_in, 'YYYY-MM')
        ORDER BY month DESC, e.full_name
    `;
    
    return query;
}

function convertToCSV(data) {
    if (!data || data.length === 0) return '';
    
    // Get headers from first object
    const headers = Object.keys(data[0]);
    
    // Create CSV content
    let csvContent = '';
    
    // Add headers
    csvContent += headers.join(',') + '\n';
    
    // Add rows
    data.forEach(row => {
        const values = headers.map(header => {
            let value = row[header];
            
            // Handle special cases
            if (value === null || value === undefined) {
                value = '';
            } else if (typeof value === 'boolean') {
                value = value ? 'Yes' : 'No';
            } else if (typeof value === 'string' && value.includes(',')) {
                value = `"${value}"`;
            }
            
            return value;
        });
        
        csvContent += values.join(',') + '\n';
    });
    
    return 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);
}

// =========== EXPORT ROUTER ===========
export default router;