// =========== ADMIN DASHBOARD STATISTICS ===========
import express from 'express';
import Employee from '../models/Employee.js';
import { generateToken, authenticate, blacklistToken } from '../utils/jwtUtils.js';
import pool from '../config/db.js'; 
import bcrypt from 'bcryptjs';


const router = express.Router();


router.get('/dashboard-stats', async (req, res) => {
    try {
        console.log('📊 Fetching admin dashboard statistics...');
        
        // Get all statistics in parallel for speed
        const [
            totalEmployees,
            todayAttendance,
            facesRegistered,
            recentActivity
        ] = await Promise.all([
            // 1. Total active employees
            pool.query('SELECT COUNT(*) as count FROM employees WHERE is_active = true'),
            
            // 2. Today's attendance count
            pool.query(`
                SELECT COUNT(DISTINCT employee_id) as count 
                FROM attendance 
                WHERE DATE(check_in) = CURRENT_DATE
            `),
            
            // 3. Employees with face registered
            pool.query('SELECT COUNT(*) as count FROM employees WHERE face_encoding IS NOT NULL'),
            
            // 4. Recent attendance (last 5)
            pool.query(`
                SELECT a.*, e.full_name, e.employee_id
                FROM attendance a
                JOIN employees e ON a.employee_id = e.id
                ORDER BY a.check_in DESC
                LIMIT 5
            `)
        ]);
        
        // Format the response
        const stats = {
            total_employees: parseInt(totalEmployees.rows[0].count),
            today_attendance: parseInt(todayAttendance.rows[0].count),
            faces_registered: parseInt(facesRegistered.rows[0].count),
            recent_activity: recentActivity.rows.map(record => ({
                employee_name: record.full_name,
                employee_id: record.employee_id,
                check_in: record.check_in,
                check_out: record.check_out,
                status: record.check_out ? 'Checked Out' : 'Checked In'
            }))
        };
        
        console.log('✅ Dashboard stats:', stats);
        
        res.json({
            success: true,
            stats: stats
        });
        
    } catch (error) {
        console.error('❌ Dashboard stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to load dashboard statistics'
        });
    }
});

// =========== ADD THESE TO YOUR EXISTING admin.js ===========

// =========== GET ALL EMPLOYEES ===========
router.get('/employees', async (req, res) => {
    try {
        console.log('📋 Fetching all employees...');
        
        // Get query parameters
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const offset = (page - 1) * limit;
        const search = req.query.search || '';
        
        let query, values;
        
        if (search) {
            // Search in name, email, or employee_id
            query = `
                SELECT id, employee_id, full_name, email, 
                       created_at, last_login, is_active,
                       CASE 
                           WHEN face_encoding IS NOT NULL AND face_encoding != '' 
                           THEN true 
                           ELSE false 
                       END as has_face
                FROM employees 
                WHERE is_active = true
                AND (full_name ILIKE $1 OR email ILIKE $1 OR employee_id ILIKE $1)
                ORDER BY created_at DESC
                LIMIT $2 OFFSET $3
            `;
            values = [`%${search}%`, limit, offset];
        } else {
            // Get all active employees
            query = `
                SELECT id, employee_id, full_name, email, 
                       created_at, last_login, is_active,
                       CASE 
                           WHEN face_encoding IS NOT NULL AND face_encoding != '' 
                           THEN true 
                           ELSE false 
                       END as has_face
                FROM employees 
                WHERE is_active = true
                ORDER BY created_at DESC
                LIMIT $1 OFFSET $2
            `;
            values = [limit, offset];
        }
        
        const result = await pool.query(query, values);
        
        // Get total count
        let countQuery = 'SELECT COUNT(*) FROM employees WHERE is_active = true';
        let countValues = [];
        
        if (search) {
            countQuery += ' AND (full_name ILIKE $1 OR email ILIKE $1 OR employee_id ILIKE $1)';
            countValues = [`%${search}%`];
        }
        
        const countResult = await pool.query(countQuery, countValues);
        const total = parseInt(countResult.rows[0].count);
        
        res.json({
            success: true,
            employees: result.rows,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });
        
    } catch (error) {
        console.error('❌ Error fetching employees:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch employees'
        });
    }
});

// =========== GET SINGLE EMPLOYEE ===========
router.get('/employees/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const query = `
            SELECT id, employee_id, full_name, email, 
                   created_at, last_login, is_active,
                   CASE 
                       WHEN face_encoding IS NOT NULL AND face_encoding != '' 
                       THEN true 
                       ELSE false 
                   END as has_face
            FROM employees 
            WHERE id = $1 AND is_active = true
        `;
        
        const result = await pool.query(query, [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        res.json({
            success: true,
            employee: result.rows[0]
        });
        
    } catch (error) {
        console.error('❌ Error fetching employee:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch employee'
        });
    }
});

/*
// =========== UPDATE EMPLOYEE (ALL FIELDS OPTIONAL) ===========
router.put('/employees/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { full_name, email, employee_id, password } = req.body;
        
        console.log('📝 Employee update request:', { id, full_name, email, employee_id, password: password ? '***' : 'not provided' });
        
        // Get current employee data first
        const currentQuery = `
            SELECT employee_id, email, full_name 
            FROM employees 
            WHERE id = $1 AND is_active = true
        `;
        
        const currentResult = await pool.query(currentQuery, [id]);
        
        if (currentResult.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        const currentEmployee = currentResult.rows[0];
        
        // Use provided values or keep existing ones
        const newEmployeeId = employee_id || currentEmployee.employee_id;
        const newFullName = full_name || currentEmployee.full_name;
        const newEmail = email || currentEmployee.email;
        
        // Check if new email or employee_id already exists (excluding current employee)
        if (email || employee_id) {
            const checkQuery = `
                SELECT id FROM employees 
                WHERE (($1 IS NOT NULL AND email = $1) OR ($2 IS NOT NULL AND employee_id = $2)) 
                AND id != $3 
                AND is_active = true
            `;
            
            const checkResult = await pool.query(checkQuery, [email, employee_id, id]);
            
            if (checkResult.rows.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Email or Employee ID already exists'
                });
            }
        }
        
        // Start building update query dynamically
        let updateQuery = `UPDATE employees SET`;
        let values = [];
        let setClauses = [];
        let paramCount = 0;
        
        // Add fields only if they are provided
        if (full_name !== undefined) {
            paramCount++;
            setClauses.push(`full_name = $${paramCount}`);
            values.push(newFullName);
        }
        
        if (email !== undefined) {
            paramCount++;
            setClauses.push(`email = $${paramCount}`);
            values.push(newEmail);
        }
        
        if (employee_id !== undefined) {
            paramCount++;
            setClauses.push(`employee_id = $${paramCount}`);
            values.push(newEmployeeId);
        }
        
        // Add password update if provided
        if (password && password.length >= 6) {
            paramCount++;
            const hashedPassword = await bcrypt.hash(password, 10);
            setClauses.push(`password_hash = $${paramCount}`);
            values.push(hashedPassword);
            console.log(`🔐 Updating password for employee ID: ${newEmployeeId}`);
        }
        
        // If nothing to update
        if (setClauses.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'No changes provided'
            });
        }
        
        // Complete the query
        paramCount++;
        updateQuery += ` ${setClauses.join(', ')} WHERE id = $${paramCount} AND is_active = true RETURNING id, employee_id, full_name, email, created_at`;
        values.push(id);
        
        console.log('Update query:', updateQuery);
        console.log('Update values:', values);
        
        const result = await pool.query(updateQuery, values);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        console.log(`✅ Employee updated: ${newFullName} (${newEmployeeId})`);
        
        res.json({
            success: true,
            message: 'Employee updated successfully',
            employee: result.rows[0]
        });
        
    } catch (error) {
        console.error('❌ Error updating employee:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update employee'
        });
    }
});

*/
// =========== UPDATE EMPLOYEE (FIXED VERSION) ===========
router.put('/employees/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { full_name, email, employee_id, password } = req.body;
        
        console.log('📝 Employee update request:', { id, full_name, email, employee_id, password: password ? '***' : 'not provided' });
        
        // Get current employee data first
        const currentQuery = `
            SELECT employee_id, email, full_name 
            FROM employees 
            WHERE id = $1 AND is_active = true
        `;
        
        const currentResult = await pool.query(currentQuery, [id]);
        
        if (currentResult.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        const currentEmployee = currentResult.rows[0];
        
        // Use provided values or keep existing ones
        const newEmployeeId = employee_id !== undefined ? employee_id : currentEmployee.employee_id;
        const newFullName = full_name !== undefined ? full_name : currentEmployee.full_name;
        const newEmail = email !== undefined ? email : currentEmployee.email;
        
        console.log('New values:', { newEmployeeId, newFullName, newEmail });
        
        // Check if new email or employee_id already exists (excluding current employee)
        if (email !== undefined || employee_id !== undefined) {
            const checkQuery = `
                SELECT id FROM employees 
                WHERE (($1::text IS NOT NULL AND email = $1) OR ($2::text IS NOT NULL AND employee_id = $2)) 
                AND id != $3 
                AND is_active = true
            `;
            
            const checkResult = await pool.query(checkQuery, [email, employee_id, id]);
            
            if (checkResult.rows.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Email or Employee ID already exists'
                });
            }
        }
        
        // Start building update query dynamically
        let updateQuery = `UPDATE employees SET`;
        let values = [];
        let setClauses = [];
        let paramCount = 0;
        
        // Add fields only if they are provided (not undefined)
        if (full_name !== undefined) {
            paramCount++;
            setClauses.push(`full_name = $${paramCount}`);
            values.push(newFullName);
            console.log(`Adding full_name: ${newFullName}`);
        }
        
        if (email !== undefined) {
            paramCount++;
            setClauses.push(`email = $${paramCount}`);
            values.push(newEmail);
            console.log(`Adding email: ${newEmail}`);
        }
        
        if (employee_id !== undefined) {
            paramCount++;
            setClauses.push(`employee_id = $${paramCount}`);
            values.push(newEmployeeId);
            console.log(`Adding employee_id: ${newEmployeeId}`);
        }
        
        // Add password update if provided
        if (password && password.length >= 6) {
            paramCount++;
            const hashedPassword = await bcrypt.hash(password, 10);
            setClauses.push(`password_hash = $${paramCount}`);
            values.push(hashedPassword);
            console.log(`🔐 Updating password for employee ID: ${newEmployeeId}`);
        }
        
        // If nothing to update
        if (setClauses.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'No changes provided'
            });
        }
        
        // Complete the query
        paramCount++;
        updateQuery += ` ${setClauses.join(', ')} WHERE id = $${paramCount} AND is_active = true RETURNING id, employee_id, full_name, email, created_at`;
        values.push(id);
        
        console.log('Update query:', updateQuery);
        console.log('Update values:', values);
        
        const result = await pool.query(updateQuery, values);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        console.log(`✅ Employee updated: ${newFullName} (${newEmployeeId})`);
        
        res.json({
            success: true,
            message: 'Employee updated successfully',
            employee: result.rows[0]
        });
        
    } catch (error) {
        console.error('❌ Error updating employee:', error);
        console.error('SQL Error details:', error.detail || error.message);
        res.status(500).json({
            success: false,
            message: 'Failed to update employee',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/*
// =========== UPDATE EMPLOYEE ===========
router.put('/employees/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { full_name, email, employee_id } = req.body;
        
        // Validation
        if (!full_name || !email || !employee_id) {
            return res.status(400).json({
                success: false,
                message: 'Name, email, and employee ID are required'
            });
        }
        
        // Check if email or employee_id already exists (excluding current employee)
        const checkQuery = `
            SELECT id FROM employees 
            WHERE (email = $1 OR employee_id = $2) 
            AND id != $3 
            AND is_active = true
        `;
        
        const checkResult = await pool.query(checkQuery, [email, employee_id, id]);
        
        if (checkResult.rows.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Email or Employee ID already exists'
            });
        }
        
        // Update employee
        const updateQuery = `
            UPDATE employees 
            SET full_name = $1, email = $2, employee_id = $3
            WHERE id = $4 AND is_active = true
            RETURNING id, employee_id, full_name, email, created_at
        `;
        
        const result = await pool.query(updateQuery, [full_name, email, employee_id, id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        console.log(`✅ Employee updated: ${full_name} (${employee_id})`);
        
        res.json({
            success: true,
            message: 'Employee updated successfully',
            employee: result.rows[0]
        });
        
    } catch (error) {
        console.error('❌ Error updating employee:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update employee'
        });
    }
});

*/

// =========== DELETE EMPLOYEE (SOFT DELETE) ===========
router.delete('/employees/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Soft delete: set is_active = false
        const query = `
            UPDATE employees 
            SET is_active = false 
            WHERE id = $1 
            RETURNING id, employee_id, full_name
        `;
        
        const result = await pool.query(query, [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        const employee = result.rows[0];
        console.log(`🗑️ Employee deactivated: ${employee.full_name} (${employee.employee_id})`);
        
        res.json({
            success: true,
            message: 'Employee deactivated successfully',
            employee: employee
        });
        
    } catch (error) {
        console.error('❌ Error deleting employee:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete employee'
        });
    }
});

// =========== ATTENDANCE VIEW ENDPOINTS ===========

// =========== GET ALL ATTENDANCE RECORDS ===========
router.get('/attendance', async (req, res) => {
    try {
        console.log('📊 Fetching all attendance records...');
        
        // Get query parameters
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const offset = (page - 1) * limit;
        
        // Query to get attendance with employee details
        const query = `
            SELECT 
                a.id,
                a.check_in,
                a.check_out,
                a.gps_lat,
                a.gps_lng,
                a.face_verified,
                a.location_verified,
                a.status,
                a.created_at,
                e.id as employee_id,
                e.employee_id as emp_code,
                e.full_name,
                e.email
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE e.is_active = true
            ORDER BY a.check_in DESC
            LIMIT $1 OFFSET $2
        `;
        
        const result = await pool.query(query, [limit, offset]);
        
        // Get total count
        const countQuery = `
            SELECT COUNT(*) 
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE e.is_active = true
        `;
        
        const countResult = await pool.query(countQuery);
        const total = parseInt(countResult.rows[0].count);
        
        // Format the data
        const attendance = result.rows.map(record => ({
            id: record.id,
            employee_id: record.emp_code,
            employee_name: record.full_name,
            email: record.email,
            check_in: record.check_in,
            check_out: record.check_out,
            gps_lat: record.gps_lat,
            gps_lng: record.gps_lng,
            face_verified: record.face_verified,
            location_verified: record.location_verified,
            status: record.status,
            created_at: record.created_at,
            work_hours: record.check_out 
                ? calculateWorkHours(record.check_in, record.check_out)
                : null
        }));
        
        res.json({
            success: true,
            attendance: attendance,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });
        
    } catch (error) {
        console.error('❌ Error fetching attendance:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch attendance records'
        });
    }
});

// =========== FILTER ATTENDANCE ===========
router.get('/attendance/filter', async (req, res) => {
    try {
        console.log('🔍 Filtering attendance records...');
        
        const { 
            startDate, 
            endDate, 
            employeeId,
            status 
        } = req.query;
        
        // Start building query
        let query = `
            SELECT 
                a.id,
                a.check_in,
                a.check_out,
                a.gps_lat,
                a.gps_lng,
                a.face_verified,
                a.location_verified,
                a.status,
                a.created_at,
                e.id as emp_db_id,
                e.employee_id as emp_code,
                e.full_name,
                e.email
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE e.is_active = true
        `;
        
        let values = [];
        let paramCount = 0;
        
        // Add filters
        if (startDate) {
            paramCount++;
            query += ` AND DATE(a.check_in) >= $${paramCount}`;
            values.push(startDate);
        }
        
        if (endDate) {
            paramCount++;
            query += ` AND DATE(a.check_in) <= $${paramCount}`;
            values.push(endDate);
        }
        
        if (employeeId) {
            paramCount++;
            query += ` AND (e.employee_id ILIKE $${paramCount} OR e.full_name ILIKE $${paramCount})`;
            values.push(`%${employeeId}%`);
        }
        
        if (status) {
            paramCount++;
            query += ` AND a.status = $${paramCount}`;
            values.push(status);
        }
        
        query += ` ORDER BY a.check_in DESC`;
        
        console.log('Filter query:', query);
        console.log('Filter values:', values);
        
        const result = await pool.query(query, values);
        
        // Format the data
        const attendance = result.rows.map(record => ({
            id: record.id,
            employee_id: record.emp_code,
            employee_name: record.full_name,
            email: record.email,
            check_in: record.check_in,
            check_out: record.check_out,
            gps_lat: record.gps_lat,
            gps_lng: record.gps_lng,
            face_verified: record.face_verified,
            location_verified: record.location_verified,
            status: record.status,
            created_at: record.created_at,
            work_hours: record.check_out 
                ? calculateWorkHours(record.check_in, record.check_out)
                : null
        }));
        
        res.json({
            success: true,
            attendance: attendance,
            count: attendance.length
        });
        
    } catch (error) {
        console.error('❌ Error filtering attendance:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to filter attendance records'
        });
    }
});

// =========== HELPER FUNCTION: CALCULATE WORK HOURS ===========
function calculateWorkHours(checkIn, checkOut) {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffMs = end - start;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${diffHours}h ${diffMinutes}m`;
}

// =========== EXPORT ATTENDANCE ===========
router.get('/attendance/export', async (req, res) => {
    try {
        console.log('📤 Exporting attendance data...');
        
        const { startDate, endDate } = req.query;
        
        let query = `
            SELECT 
                a.id,
                a.check_in,
                a.check_out,
                a.gps_lat,
                a.gps_lng,
                a.face_verified,
                a.location_verified,
                a.status,
                a.created_at,
                e.employee_id as emp_code,
                e.full_name,
                e.email
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE e.is_active = true
        `;
        
        let values = [];
        
        if (startDate && endDate) {
            query += ` AND DATE(a.check_in) BETWEEN $1 AND $2`;
            values.push(startDate, endDate);
        }

        if (req.query.employeeId) {
            const paramIndex = values.length + 1;
            query += ` AND (e.employee_id ILIKE $${paramIndex} OR e.full_name ILIKE $${paramIndex})`;
            values.push(`%${req.query.employeeId}%`);
        }
        
        query += ` ORDER BY a.check_in DESC`;
        
        const result = await pool.query(query, values);
        
        // Convert to CSV format
        let csvContent = "data:text/csv;charset=utf-8,";
        
        // CSV headers
        const headers = [
            'ID',
            'Employee ID',
            'Employee Name',
            'Email',
            'Check In',
            'Check Out',
            'Work Hours',
            'GPS Latitude',
            'GPS Longitude',
            'Face Verified',
            'Location Verified',
            'Status',
            'Date'
        ];
        
        csvContent += headers.join(',') + "\n";
        
        // Add rows
        result.rows.forEach(record => {
            const workHours = record.check_out 
                ? calculateWorkHours(record.check_in, record.check_out)
                : '--';
            
            const row = [
                record.id,
                `"${record.emp_code}"`,
                `"${record.full_name}"`,
                `"${record.email}"`,
                `"${new Date(record.check_in).toLocaleString()}"`,
                record.check_out ? `"${new Date(record.check_out).toLocaleString()}"` : '--',
                `"${workHours}"`,
                record.gps_lat || '',
                record.gps_lng || '',
                record.face_verified ? 'Yes' : 'No',
                record.location_verified ? 'Yes' : 'No',
                `"${record.status || 'present'}"`,
                `"${new Date(record.check_in).toLocaleDateString()}"`
            ];
            
            csvContent += row.join(',') + "\n";
        });
        
        // Send filename suggestion
        const fileName = `attendance_${new Date().toISOString().split('T')[0]}.csv`;
        
        res.json({
            success: true,
            csv: csvContent,
            filename: fileName,
            count: result.rows.length
        });
        
    } catch (error) {
        console.error('❌ Error exporting attendance:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to export attendance data'
        });
    }
});



export default router;