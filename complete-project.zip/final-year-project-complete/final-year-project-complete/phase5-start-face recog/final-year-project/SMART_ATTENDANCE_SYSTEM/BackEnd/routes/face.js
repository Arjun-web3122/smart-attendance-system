// =========== FACE REGISTRATION ROUTES ===========
// =========== FACE REGISTRATION ROUTES ===========
import express from 'express';
import Employee from '../models/Employee.js';
import pool from '../config/db.js';  // ← ADD THIS LINE

const router = express.Router();


// =========== REGISTER EMPLOYEE WITH FACE ===========
// =========== REGISTER EMPLOYEE WITH FACE ===========
router.post('/register-employee', async (req, res) => {
    try {
        const { employee_id, full_name, email, password, face_descriptor } = req.body;
        
        console.log(`👤 Registering employee: ${full_name} (${employee_id})`);
        console.log(`Face descriptor size: ${face_descriptor ? face_descriptor.length : 0}`);
        console.log(`Face descriptor type: ${typeof face_descriptor}`);
        console.log(`Face descriptor first 5 values: ${face_descriptor ? face_descriptor.slice(0, 5) : 'none'}`);
        
        // Validate required fields
        if (!employee_id || !full_name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Employee ID, name, email, and password are required'
            });
        }
        
        // Create employee first
        const employeeData = { employee_id, full_name, email, password };
        const employee = await Employee.create(employeeData);
        
        // If face descriptor provided, save it
        if (face_descriptor && Array.isArray(face_descriptor)) {
            if (face_descriptor.length !== 128) {
                console.warn(`Face descriptor has ${face_descriptor.length} elements, expected 128`);
                return res.status(400).json({
                    success: false,
                    message: 'Face descriptor must have exactly 128 numbers'
                });
            }
            
            // Convert array to JSON string for TEXT column
            const faceJsonString = JSON.stringify(face_descriptor);
            console.log(`Converting face data to JSON string, length: ${faceJsonString.length}`);
            
            await Employee.updateFaceEncoding(employee_id, faceJsonString);
            console.log(`✅ Face registered for: ${full_name}`);
        }
        
        res.json({
            success: true,
            message: 'Employee registered successfully',
            employee: {
                id: employee.id,
                employee_id: employee.employee_id,
                full_name: employee.full_name,
                email: employee.email,
                has_face: !!face_descriptor
            }
        });
        
    } catch (error) {
        console.error('Error registering employee:', error);
        console.error('Error stack:', error.stack);
        
        // Handle specific errors
        let errorMessage = error.message;
        if (error.message.includes('already exists')) {
            errorMessage = 'Employee ID or email already exists';
        } else if (error.message.includes('JSON')) {
            errorMessage = 'Invalid face data format. Please try capturing face again.';
        }
        
        res.status(500).json({
            success: false,
            message: errorMessage,
            errorDetails: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// =========== UPDATE FACE ONLY ===========
router.post('/update-face', async (req, res) => {
    try {
        const { employee_id, face_descriptor } = req.body;
        
        if (!employee_id || !face_descriptor) {
            return res.status(400).json({
                success: false,
                message: 'Employee ID and face descriptor are required'
            });
        }
        
        if (!Array.isArray(face_descriptor) || face_descriptor.length !== 128) {
            return res.status(400).json({
                success: false,
                message: 'Face descriptor must be an array of 128 numbers'
            });
        }
        
        // Update face encoding
        const result = await Employee.updateFaceEncoding(employee_id, face_descriptor);
        
        res.json({
            success: true,
            message: 'Face data updated successfully',
            employee: result
        });
        
    } catch (error) {
        console.error('Error updating face:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to update face data'
        });
    }
});


// =========== VERIFY FACE ===========
router.post('/verify', async (req, res) => {
    try {
        const { employee_id, face_descriptor } = req.body;
        
        console.log(`🔍 Face verification request for employee: ${employee_id}`);
        console.log(`Face descriptor length: ${face_descriptor ? face_descriptor.length : 0}`);
        
        // Validate input
        if (!employee_id || !face_descriptor) {
            return res.status(400).json({
                success: false,
                message: 'Employee ID and face descriptor are required'
            });
        }
        
        if (!Array.isArray(face_descriptor) || face_descriptor.length !== 128) {
            return res.status(400).json({
                success: false,
                message: 'Face descriptor must be an array of 128 numbers'
            });
        }
        
        // 1. Get employee's stored face from database
        const employee = await Employee.findByEmployeeId(employee_id);
        
        if (!employee) {
            return res.status(404).json({
                success: false,
                message: 'Employee not found'
            });
        }
        
        if (!employee.face_encoding) {
            return res.status(400).json({
                success: false,
                message: 'Employee does not have face registered'
            });
        }
        
        // 2. Parse stored face data (it's stored as JSON string)
        let storedFace;
        try {
            storedFace = JSON.parse(employee.face_encoding);
        } catch (error) {
            console.error('Error parsing stored face data:', error);
            return res.status(500).json({
                success: false,
                message: 'Error reading stored face data'
            });
        }
        
        // 3. Compare faces (simple Euclidean distance)
        const distance = calculateFaceDistance(face_descriptor, storedFace);
        
        // 4. Determine if it's a match (threshold: 0.6)
        const isMatch = distance < 0.6;
        const confidence = Math.max(0, 100 - (distance * 100));
        
        console.log(`Face comparison result:`);
        console.log(`  Distance: ${distance.toFixed(4)}`);
        console.log(`  Match: ${isMatch}`);
        console.log(`  Confidence: ${confidence.toFixed(1)}%`);
        
        // 5. Return result
        res.json({
            success: true,
            isMatch: isMatch,
            distance: distance,
            confidence: confidence,
            message: isMatch ? 'Face verified successfully!' : 'Face does not match'
        });
        
    } catch (error) {
        console.error('Face verification error:', error);
        res.status(500).json({
            success: false,
            message: 'Face verification failed',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// =========== FACE COMPARISON FUNCTION ===========
function calculateFaceDistance(face1, face2) {
    // Calculate Euclidean distance between two face descriptors
    let sum = 0;
    
    for (let i = 0; i < 128; i++) {
        const diff = face1[i] - face2[i];
        sum += diff * diff;
    }
    
    return Math.sqrt(sum);
}

// =========== TEST FACE VERIFICATION ===========
router.post('/test-verify', async (req, res) => {
    try {
        // Test with dummy data
        const testFace = new Array(128).fill(0.5); // All 0.5 values
        
        // Get any employee with face data
        const query = `
            SELECT employee_id, face_encoding 
            FROM employees 
            WHERE face_encoding IS NOT NULL 
            LIMIT 1
        `;
        
        const result = await pool.query(query);
        
        if (result.rows.length === 0) {
            return res.json({
                success: false,
                message: 'No employees with face data found'
            });
        }
        
        const employee = result.rows[0];
        const storedFace = JSON.parse(employee.face_encoding);
        
        const distance = calculateFaceDistance(testFace, storedFace);
        const isMatch = distance < 0.6;
        const confidence = Math.max(0, 100 - (distance * 100));
        
        res.json({
            success: true,
            testResult: {
                employee_id: employee.employee_id,
                distance: distance,
                isMatch: isMatch,
                confidence: confidence,
                message: isMatch ? 'Test passed!' : 'Test failed - different face'
            }
        });
        
    } catch (error) {
        console.error('Test error:', error);
        res.status(500).json({
            success: false,
            message: 'Test failed',
            error: error.message
        });
    }
});

export default router;