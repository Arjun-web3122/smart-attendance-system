
/*
import express from 'express';
import Attendance from '../models/Attendance.js';
import { authenticate } from '../utils/jwtUtils.js';
import { verifyLocation } from '../utils/gpsUtils.js';


const router = express.Router();

// MARK ATTENDANCE (WITH GPS VERIFICATION)
router.post('/mark', authenticate(), async (req, res) => {
    try {
        const { gps_lat, gps_lng, face_verified } = req.body;
        
        // Get employee ID from authenticated user
        const employee_id = req.user.id;
        
        // 1. VERIFY GPS LOCATION
        const locationVerification = verifyLocation(gps_lat, gps_lng);
        
        if (!locationVerification.is_within_radius) {
            return res.status(400).json({
                success: false,
                message: `Attendance failed: ${locationVerification.message}`,
                location_details: locationVerification
            });
        }
        
        // 2. RECORD ATTENDANCE (only if GPS verification passes)
        const attendance = await Attendance.checkIn({
            employee_id,
            gps_lat,
            gps_lng,
            face_verified: face_verified || false,
            location_verified: true // Now we verified it!
        });
        
        // 3. RETURN SUCCESS
        res.json({
            success: true,
            message: 'Attendance marked successfully',
            attendance: attendance,
            location_verified: true,
            location_details: locationVerification
        });
        
    } catch (error) {
        console.error('Error marking attendance:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to mark attendance'
        });
    }
});

// CHECK OUT
router.post('/checkout', authenticate(), async (req, res) => {
    try {
        const employee_id = req.user.id;
        
        const attendance = await Attendance.checkOut(employee_id);
        
        res.json({
            success: true,
            message: 'Checked out successfully',
            attendance
        });
        
    } catch (error) {
        console.error('Error during check-out:', error);
        
        // If no active check-in found, that's okay - user might not have checked in
        if (error.message.includes('No active check-in')) {
            return res.json({
                success: true,
                message: 'No active check-in to check out from'
            });
        }
        
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to check out'
        });
    }
});

// GET TODAY'S ATTENDANCE
router.get('/today', authenticate(), async (req, res) => {
    try {
        const employee_id = req.user.id;
        const today = new Date().toISOString().split('T')[0];
        
        const attendance = await Attendance.findTodayAttendance(employee_id, today);
        
        res.json({
            success: true,
            attendance: attendance || null
        });
        
    } catch (error) {
        console.error('Error getting today attendance:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get today\'s attendance'
        });
    }
});

// GET ATTENDANCE HISTORY
router.get('/history', authenticate(), async (req, res) => {
    try {
        const employee_id = req.user.id;
        const { startDate, endDate } = req.query;
        
        const history = await Attendance.getEmployeeHistory(
            employee_id, 
            startDate, 
            endDate
        );
        
        res.json({
            success: true,
            history: history || []
        });
        
    } catch (error) {
        console.error('Error getting attendance history:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to load attendance history'
        });
    }
});

export default router;
*/

import express from 'express';
import Attendance from '../models/Attendance.js';
import { authenticate } from '../utils/jwtUtils.js';
import { verifyLocation } from '../utils/gpsUtils.js';

const router = express.Router();

// MARK ATTENDANCE (GPS + FACE CONFIDENCE)
router.post('/mark', authenticate(), async (req, res) => {
    try {
        const { gps_lat, gps_lng, face_verified, face_confidence } = req.body;
        const employee_id = req.user.id;

        // 🔐 FACE VERIFICATION HARD RULE
        if (!face_verified || !face_confidence || face_confidence < 70) {
            return res.status(403).json({
                success: false,
                message: 'Face verification failed. Minimum confidence is 70%.'
            });
        }

        // 📍 GPS CHECK
        const locationVerification = verifyLocation(gps_lat, gps_lng);

        if (!locationVerification.is_within_radius) {
            return res.status(400).json({
                success: false,
                message: `Attendance failed: ${locationVerification.message}`,
                location_details: locationVerification
            });
        }

        // ✅ SAVE ATTENDANCE
        const attendance = await Attendance.checkIn({
            employee_id,
            gps_lat,
            gps_lng,
            face_verified: true,
            location_verified: true
        });

        res.json({
            success: true,
            message: 'Attendance marked successfully',
            attendance,
            location_verified: true,
            location_details: locationVerification
        });

    } catch (error) {
        console.error('Attendance error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to mark attendance'
        });
    }
});
// CHECK OUT
router.post('/checkout', authenticate(), async (req, res) => {
    try {
        const employee_id = req.user.id;
        console.log(`Attempting check-out for employee: ${employee_id} (${req.user.name})`);
        
        const attendance = await Attendance.checkOut(employee_id);
        
        res.json({
            success: true,
            message: 'Checked out successfully',
            attendance: attendance,
            check_out_time: attendance.check_out
        });
        
    } catch (error) {
        console.error('Error during check-out:', error);
        
        // Provide more specific messages
        if (error.message.includes('No check-in found')) {
            return res.json({
                success: false,
                message: 'You have not checked in today'
            });
        }
        
        if (error.message.includes('Already checked out')) {
            return res.json({
                success: false,
                message: error.message
            });
        }
        
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to check out'
        });
    }
});

/*

// CHECK OUT
router.post('/checkout', authenticate(), async (req, res) => {
    try {
        const employee_id = req.user.id;
        const attendance = await Attendance.checkOut(employee_id);

        res.json({
            success: true,
            message: 'Checked out successfully',
            attendance
        });

    } catch (error) {
        if (error.message.includes('No active check-in')) {
            return res.json({
                success: true,
                message: 'No active check-in found'
            });
        }

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

*/

// TODAY STATUS
router.get('/today', authenticate(), async (req, res) => {
    try {
        const attendance = await Attendance.findTodayAttendance(req.user.id);

        res.json({
            success: true,
            attendance: attendance || null
        });
    }
 catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch today attendance'
        });
    }
});

// HISTORY
router.get('/history', authenticate(), async (req, res) => {
    try {
        const history = await Attendance.getEmployeeHistory(
            req.user.id,
            req.query.startDate,
            req.query.endDate
        );

        res.json({ success: true, history: history || [] });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to load history'
        });
    }
});

export default router;
