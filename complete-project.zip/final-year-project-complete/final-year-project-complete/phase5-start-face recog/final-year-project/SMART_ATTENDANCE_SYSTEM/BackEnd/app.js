// =========== IMPORT MODULES ===========
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import analyticsRoutes from './routes/analytics.js';

import faceRoutes from './routes/face.js';
// Add this import near the top with other imports
import attendanceRoutes from './routes/attendance.js';

// Add this line after app.use('/api/auth', authRoutes);

import adminRoutes from './routes/admin.js';






// Import routes
import authRoutes from './routes/auth.js';
import { testConnection } from './config/db.js';

dotenv.config();

// =========== INITIALIZE EXPRESS ===========
const app = express();
const PORT = process.env.PORT || 3000;

// =========== MIDDLEWARE SETUP ===========
app.use(helmet());
app.use(cors({
    origin: true, // Allow all origins (not recommended for production)
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());


// =========== DATABASE CONNECTION TEST ===========
// Test DB connection on startup
testConnection().then(success => {
    if (success) {
        console.log('✅ Database connection verified');
    } else {
        console.warn('⚠️  Database connection issues - check configuration');
    }
});

// =========== ROUTES ===========
// Health check
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'Server is running',
        services: {
            database: 'connected',
            authentication: 'available',
            timestamp: new Date().toISOString()
        }
    });
});



// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/face', faceRoutes);


app.use('/api/admin', adminRoutes);

// Global error handler
app.use((err, req, res, next) => {
    console.error('🔥 Server Error:', err.stack);
    res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});


app.use('/api/face', faceRoutes);
app.use('/api/admin/analytics', analyticsRoutes);




// =========== START SERVER ===========
app.listen(PORT, () => {
    console.log(`
    🚀 Smart Attendance System Backend
    📡 Port: ${PORT}
    🌍 URL: http://localhost:${PORT}
    📊 Health: http://localhost:${PORT}/api/health
    🔐 Auth: http://localhost:${PORT}/api/auth/health
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('👋 SIGTERM received. Shutting down gracefully...');
    process.exit(0);
});